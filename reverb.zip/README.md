# NEXUSPACE — reverb

NEXUSPACE is a custom algorithmic reverb built around the concept **clear front / living tail**.


## Canonical project/package names
- Work folder / repository slug: `reverb`
- Source/project ZIP: `reverb.zip`
- macOS build ZIP: `NEXUSPACE-macOS.zip`
- Current version: `0.3.0`
- For now, build delivery is macOS only, targeting Intel x86-64 / iMac 2011 compatibility.

## Architecture
- 100% custom C++ DSP core
- JUCE only as VST3 / host / GUI wrapper
- custom early-reflection engine
- custom diffusion network
- custom 8-line FDN
- frequency-dependent RT60 feedback shaping
- transient-aware Focus with deferred injection
- Bloom, modulation, width, tone, low-end control and damping

## CPU / compatibility direction
The code avoids modern CPU-only assumptions and remains targeted at Intel x86-64 compatibility for the iMac 2011 project goal. The DSP has no audio-thread allocations in the included realtime test.

## Build
See `BUILD_MACOS_2011.md`.

## Tests
Build the `Tests` directory independently and run:

```bash
cmake -S Tests -B Tests/build -DCMAKE_BUILD_TYPE=Release
cmake --build Tests/build -j2
ctest --test-dir Tests/build --output-on-failure
```

See `SOUND_AUDIT_REPORT.md` for the current sound/stability results.
