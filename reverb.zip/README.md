# NEXUSPACE — reverb

NEXUSPACE is a custom algorithmic reverb built around the concept **clear front / living tail**.

## Canonical project/package names
- Work folder / repository slug: `reverb`
- Source/project ZIP: `reverb.zip`
- macOS build ZIP: `NEXUSPACE-macOS.zip`
- Current version: `0.4.0`
- For now, build delivery is macOS only, targeting Intel x86-64 / iMac 2011 compatibility.

## Architecture
- 100% custom C++ DSP core
- official Steinberg VST3 SDK for plug-in lifecycle, host integration, parameters and state
- Steinberg VSTGUI only for the editor/view layer
- no JUCE dependency anywhere in the active build
- custom early-reflection engine
- custom diffusion network
- custom 8-line FDN
- frequency-dependent RT60 feedback shaping
- transient-aware Focus with deferred injection
- Bloom, modulation, width, tone, low-end control and damping

## UI rule
`Design/NEXUSPACE_GUI_TARGET.png` remains a visual target/reference only. It is never used as a fake clickable faceplate. The active Steinberg/VSTGUI editor uses real parameter controls. Numeric controls have direct text-entry fields; parameter defaults are carried by the VST3 parameter model.

## CPU / compatibility direction
The code avoids modern CPU-only assumptions and remains targeted at Intel x86-64 compatibility for the iMac 2011 project goal. The DSP has no audio-thread allocations in the included realtime test.

## Build
See `BUILD_MACOS_2011.md`.

## Tests
Build the `Tests` directory independently and run:

```bash
cmake -S Tests -B Tests/build -DCMAKE_BUILD_TYPE=Release
cmake --build Tests/build -j2
ctest --test-dir Tests/build --output-on-failure
```

See `SOUND_AUDIT_REPORT.md` for the current sound/stability results.
