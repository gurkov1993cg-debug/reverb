# NEXUSPACE / reverb — Project Rules

## Canonical project identity
- GitHub repository: `gurkov1993cg-debug/reverb`
- Canonical local/work folder: `reverb`
- Plugin/product name: `NEXUSPACE`
- Current company/brand label used in the project: `VETRA AUDIO`

## Canonical package names
- Project/source archive: `reverb.zip`
- macOS build archive: `NEXUSPACE-macOS.zip`
- New revisions overwrite these same filenames. Do not create versioned ZIP filenames.
- Version information belongs inside the project (`CMakeLists.txt`, `CHANGELOG.md`, source metadata) and in Git history/tags.

## Build delivery rule
- For now, deliver macOS builds only unless another platform is explicitly requested.
- Primary compatibility target: Intel x86-64 / iMac 2011.
- Do not provide Windows/Linux builds by default.

## Repository rule
- GitHub is the primary source of truth for source, build files, documentation, assets and project history.
- Do not create a parallel disconnected code line outside the project repository.

## Development workflow
- Work continuously through logical substeps until a real milestone/result is ready.
- Do not stop merely to provide intermediate status explanations.
- Report when a usable result/file is ready or when a real technical blocker requires user action.
## GitHub Actions workflow rule
- Every plugin/software repository must contain a `.github/workflows/` directory.
- During the current macOS-only phase, every plugin repository must contain `.github/workflows/build-macos.yml`.
- GitHub Actions is the standard build path for repeatable macOS builds.
- The workflow file name remains stable (`build-macos.yml`) rather than being duplicated per version.


## Automatic GitHub Actions build
- Every plugin repository keeps `.github/workflows/build-macos.yml` as the stable macOS build workflow while macOS is the active target.
- A push to `main` must automatically run DSP tests and build the macOS plugin.
- The downloadable macOS artifact keeps the constant name `NEXUSPACE-macOS.zip`; version information belongs inside the project, Git history and changelog, not in the ZIP filename.
- GitHub Actions must use an Intel runner for the iMac 2011 compatibility line and must verify the produced binary is x86_64.
