#include "../Source/DSP/NxReverbEngine.hpp"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <vector>

namespace {
constexpr int kSr=48000;

struct LP {
    double a=0.0,z=0.0;
    explicit LP(double hz){ a=std::exp(-2.0*3.14159265358979323846*hz/kSr); }
    double process(double x){ z=(1.0-a)*x+a*z; return z; }
};

struct IR { std::vector<float> l,r; };

IR render(nx::ReverbParameters p,double seconds){
    const int n=(int)(seconds*kSr), block=256;
    IR ir{std::vector<float>(n,0.0f),std::vector<float>(n,0.0f)};
    ir.l[0]=ir.r[0]=1.0f;
    nx::ReverbEngine rev; rev.setParameters(p); rev.prepare(kSr,block);
    for(int pos=0;pos<n;pos+=block) rev.process(ir.l.data()+pos,ir.r.data()+pos,std::min(block,n-pos));
    return ir;
}

double energy(const IR& x,double a,double b){
    int i0=std::max(0,(int)(a*kSr)),i1=std::min((int)x.l.size(),(int)(b*kSr));
    double e=0.0;for(int i=i0;i<i1;++i)e+=(double)x.l[i]*x.l[i]+(double)x.r[i]*x.r[i];return e;
}

double corr(const IR& x,double a,double b){
    int i0=std::max(0,(int)(a*kSr)),i1=std::min((int)x.l.size(),(int)(b*kSr));
    double aa=0,bb=0,ab=0;for(int i=i0;i<i1;++i){double l=x.l[i],r=x.r[i];aa+=l*l;bb+=r*r;ab+=l*r;}return ab/std::sqrt(std::max(1e-30,aa*bb));
}

// Lightweight mid-band RT estimate used only by this offline audit.
double midRt60(const IR& x,double startSec){
    const int start=(int)(startSec*kSr), n=(int)x.l.size()-start;
    if(n<1000)return 0.0;
    LP low500(500.0), low4000(4000.0);
    std::vector<double> e((std::size_t)n);
    for(int k=0;k<n;++k){
        int i=start+k;double mono=0.5*((double)x.l[i]+x.r[i]);
        double hp=mono-low500.process(mono);
        double bp=low4000.process(hp);
        e[(std::size_t)k]=bp*bp;
    }
    for(int i=n-2;i>=0;--i)e[(std::size_t)i]+=e[(std::size_t)i+1];
    if(e[0]<=1e-30)return 0.0;
    const double e0=e[0];double sx=0,sy=0,sxx=0,sxy=0;long count=0;
    for(int i=0;i<n;++i){
        const double db=10.0*std::log10(std::max(1e-30,e[(std::size_t)i]/e0));
        if(db<=-5.0 && db>=-35.0){double t=(double)i/kSr;sx+=t;sy+=db;sxx+=t*t;sxy+=t*db;++count;}
    }
    if(count<100)return 0.0;
    const double denom=count*sxx-sx*sx;if(std::fabs(denom)<1e-20)return 0.0;
    const double slope=(count*sxy-sx*sy)/denom;
    return slope<0.0?-60.0/slope:0.0;
}
}

int main(){
    bool pass=true;
    std::cout<<std::fixed<<std::setprecision(3);

    // 1) Nominal 4.2 s decay should behave like a mid-band RT60, not just a knob label.
    double modeEnergy[4]{};
    for(int mode=0;mode<4;++mode){
        nx::ReverbParameters p;p.spaceType=(float)mode;p.mix=1.0f;p.predelayMs=0.0f;p.focus=0.0f;p.earlyLevelDb=-24.0f;p.decaySeconds=4.2f;
        auto ir=render(p,10.0);
        const double rt=midRt60(ir,0.35);
        const double c=corr(ir,0.20,4.0);
        modeEnergy[mode]=energy(ir,0.0,4.0);
        const bool okRt=rt>3.45 && rt<4.75;
        const bool okStereo=std::fabs(c)<0.35;
        pass=pass&&okRt&&okStereo;
        std::cout<<"mode="<<mode<<" midRT60="<<rt<<"s stereoCorr="<<c<<" energy="<<modeEnergy[mode]<<" rtPass="<<okRt<<" stereoPass="<<okStereo<<"\n";
    }

    const double eMin=*std::min_element(modeEnergy,modeEnergy+4),eMax=*std::max_element(modeEnergy,modeEnergy+4);
    const double spreadDb=10.0*std::log10(eMax/std::max(1e-30,eMin));
    const bool modeLevelPass=spreadDb<3.0;pass=pass&&modeLevelPass;
    std::cout<<"spaceEnergySpread="<<spreadDb<<"dB pass="<<modeLevelPass<<"\n";

    // 2) Focus must still work when predelay is used, and should move more transient
    // energy later rather than deleting the whole tail.
    double earlyRatio[2]{},totalRatio[2]{};
    const float pds[2]={0.0f,100.0f};
    for(int k=0;k<2;++k){
        nx::ReverbParameters p;p.mix=1.0f;p.earlyLevelDb=-24.0f;p.predelayMs=pds[k];p.decaySeconds=4.2f;
        p.focus=0.0f;auto a=render(p,3.0);p.focus=1.0f;auto b=render(p,3.0);
        const double off=pds[k]*0.001;
        earlyRatio[k]=energy(b,off+0.02,off+0.12)/std::max(1e-30,energy(a,off+0.02,off+0.12));
        totalRatio[k]=energy(b,off+0.02,off+1.50)/std::max(1e-30,energy(a,off+0.02,off+1.50));
        std::cout<<"focusPredelay="<<pds[k]<<"ms earlyEnergyRatio="<<earlyRatio[k]<<" totalTailRatio="<<totalRatio[k]<<"\n";
    }
    const bool focusPass=earlyRatio[0]>0.35&&earlyRatio[0]<0.72&&earlyRatio[1]>0.35&&earlyRatio[1]<0.72&&
        totalRatio[0]>0.65&&totalRatio[0]<0.95&&totalRatio[1]>0.65&&totalRatio[1]<0.95&&
        std::fabs(earlyRatio[0]-earlyRatio[1])<0.08;
    pass=pass&&focusPass;std::cout<<"focusAlignmentPass="<<focusPass<<"\n";

    // 3) Worst-case long Room decay must decrease, never self-build.
    nx::ReverbParameters stress;stress.spaceType=2.0f;stress.mix=1.0f;stress.predelayMs=0.0f;stress.focus=0.0f;stress.earlyLevelDb=-24.0f;stress.decaySeconds=20.0f;stress.damping=0.0f;stress.lowControl=0.0f;stress.modulation=1.0f;
    auto longIr=render(stress,12.0);
    const double eA=energy(longIr,4.0,5.0),eB=energy(longIr,10.0,11.0);
    const bool longPass=std::isfinite(eA)&&std::isfinite(eB)&&eB<eA;pass=pass&&longPass;
    std::cout<<"longDecayEnergy4to5="<<eA<<" energy10to11="<<eB<<" pass="<<longPass<<"\n";

    std::cout<<"SOUND_AUDIT_PASS="<<pass<<"\n";
    return pass?0:1;
}
