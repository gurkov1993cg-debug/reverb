#include "../Source/DSP/NxReverbEngine.hpp"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>

static double energyRange(const std::vector<float>& a,const std::vector<float>& b,int begin,int end){
    double e=0.0;
    begin=std::max(0,begin); end=std::min(end,(int)a.size());
    for(int i=begin;i<end;++i)e+=(double)a[i]*a[i]+(double)b[i]*b[i];
    return e;
}
static double correlation(const std::vector<float>& a,const std::vector<float>& b,int begin,int end){
    double ab=0.0,aa=0.0,bb=0.0;
    begin=std::max(0,begin); end=std::min(end,(int)a.size());
    for(int i=begin;i<end;++i){ab+=(double)a[i]*b[i];aa+=(double)a[i]*a[i];bb+=(double)b[i]*b[i];}
    return ab/std::sqrt(std::max(1.0e-30,aa*bb));
}

int main(){
    bool ok=true;
    const int sampleRates[3]={44100,48000,96000};
    for(int sr:sampleRates){
        for(int mode=0;mode<4;++mode){
            const int n=sr*4;
            std::vector<float> l(n,0.0f),r(n,0.0f);
            // Mono impulse is intentional: v0.1 had a cancellation bug at the FDN input.
            l[0]=r[0]=1.0f;
            nx::ReverbEngine rev;
            nx::ReverbParameters p;
            p.spaceType=(float)mode;
            p.mix=1.0f;
            p.predelayMs=0.0f;
            p.decaySeconds=3.2f;
            p.focus=0.0f;
            rev.setParameters(p);
            rev.prepare(sr,512);
            for(int pos=0;pos<n;pos+=257){
                const int count=std::min(257,n-pos);
                rev.process(l.data()+pos,r.data()+pos,count);
            }
            bool finite=true;
            double peak=0.0;
            for(int i=0;i<n;++i){
                finite=finite&&std::isfinite(l[i])&&std::isfinite(r[i]);
                peak=std::max(peak,(double)std::max(std::fabs(l[i]),std::fabs(r[i])));
            }
            const double late=energyRange(l,r,(int)(0.18*sr),(int)(2.8*sr));
            const double corr=correlation(l,r,(int)(0.12*sr),(int)(2.5*sr));
            const bool pass=finite && peak<4.0 && late>1.0e-5 && std::fabs(corr)<0.9995;
            std::cout<<"sr="<<sr<<" mode="<<mode<<" finite="<<finite<<" peak="<<peak<<" late="<<late<<" corr="<<corr<<" pass="<<pass<<"\n";
            ok=ok&&pass;
        }
    }

    // Mode switch should fade the wet field instead of hard-jumping delay taps.
    {
        constexpr int sr=48000, block=128, blocks=180;
        std::vector<float> l(block),r(block);
        nx::ReverbEngine rev;
        nx::ReverbParameters p;
        p.mix=1.0f; p.predelayMs=0.0f; p.decaySeconds=5.0f; p.focus=0.0f;
        rev.setParameters(p); rev.prepare(sr,block);
        double phase=0.0, maxJump=0.0; float prevL=0.0f,prevR=0.0f;
        for(int b=0;b<blocks;++b){
            if(b==60){p.spaceType=3.0f; rev.setParameters(p);}
            for(int i=0;i<block;++i){
                l[i]=0.08f*(float)std::sin(phase);
                r[i]=0.08f*(float)std::sin(phase*1.0017);
                phase+=2.0*3.14159265358979323846*220.0/sr;
            }
            rev.process(l.data(),r.data(),block);
            for(int i=0;i<block;++i){
                maxJump=std::max(maxJump,(double)std::fabs(l[i]-prevL));
                maxJump=std::max(maxJump,(double)std::fabs(r[i]-prevR));
                prevL=l[i];prevR=r[i];
            }
        }
        const bool pass=std::isfinite(maxJump)&&maxJump<1.0;
        std::cout<<"mode_switch_max_sample_jump="<<maxJump<<" pass="<<pass<<"\n";
        ok=ok&&pass;
    }

    return ok?0:1;
}
