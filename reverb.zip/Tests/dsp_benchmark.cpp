#include "../Source/DSP/NxReverbEngine.hpp"
#include <chrono>
#include <iostream>
#include <vector>
#include <cmath>
int main(){constexpr int sr=48000, block=256, seconds=30, total=sr*seconds;std::vector<float> l(block),r(block);nx::ReverbEngine rev;rev.prepare(sr,block);nx::ReverbParameters p;p.decaySeconds=8.0f;p.modulation=0.65f;p.diffusion=0.9f;p.mix=1.0f;rev.setParameters(p);double ph=0;auto t0=std::chrono::high_resolution_clock::now();for(int done=0;done<total;done+=block){for(int i=0;i<block;++i){l[i]=0.1f*std::sin(ph);r[i]=0.1f*std::sin(ph*1.003);ph+=2.0*3.141592653589793*440.0/sr;}rev.process(l.data(),r.data(),block);}auto t1=std::chrono::high_resolution_clock::now();double elapsed=std::chrono::duration<double>(t1-t0).count();std::cout<<"processed_audio_seconds="<<seconds<<" wall_seconds="<<elapsed<<" realtime_x="<<(seconds/elapsed)<<"\n";return std::isfinite(elapsed)&&elapsed<seconds?0:1;}
