#include "../Source/DSP/NxReverbEngine.hpp"
#include <cmath>
#include <iostream>
#include <vector>

int main(){
    constexpr int sr=48000, n=sr*3;
    std::vector<float> l(n,0.0f),r(n,0.0f); l[0]=r[0]=1.0f;
    nx::ReverbEngine rev; rev.prepare(sr,512); nx::ReverbParameters p; p.mix=1.0f; p.predelayMs=0.0f; p.decaySeconds=3.5f; rev.setParameters(p);
    for(int pos=0;pos<n;pos+=256) rev.process(l.data()+pos,r.data()+pos,std::min(256,n-pos));
    double energy=0.0,maxAbs=0.0; bool finite=true;
    for(int i=0;i<n;++i){finite=finite&&std::isfinite(l[i])&&std::isfinite(r[i]);energy+=l[i]*l[i]+r[i]*r[i];maxAbs=std::max(maxAbs,(double)std::max(std::fabs(l[i]),std::fabs(r[i])));}
    std::cout<<"finite="<<finite<<" energy="<<energy<<" peak="<<maxAbs<<"\n";
    return (finite && energy>1e-5 && maxAbs<10.0)?0:1;
}
