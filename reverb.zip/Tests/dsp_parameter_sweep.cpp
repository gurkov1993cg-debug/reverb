#include "../Source/DSP/NxReverbEngine.hpp"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>

int main(){
    constexpr int sr=48000,block=192,steps=420;
    nx::ReverbEngine rev; nx::ReverbParameters p; rev.setParameters(p); rev.prepare(sr,block);
    std::vector<float> l(block),r(block);double phase=0.0;bool finite=true;double peak=0.0;
    for(int s=0;s<steps;++s){
        const float t=(float)s/(steps-1);
        p.spaceType=(float)(s%4);
        p.decaySeconds=0.25f+19.75f*t;
        p.predelayMs=250.0f*(1.0f-t);
        p.bloom=t;
        p.focus=1.0f-t;
        p.width=1.5f*t;
        p.tone=-1.0f+2.0f*t;
        p.modulation=t;
        p.modRateHz=0.03f+1.17f*t;
        p.earlyLevelDb=-24.0f+30.0f*t;
        p.earlySize=t;
        p.earlyCharacter=1.0f-t;
        p.lowControl=t;
        p.damping=1.0f-t;
        p.diffusion=t;
        p.mix=t;
        p.outputDb=-12.0f+12.0f*t;
        rev.setParameters(p);
        for(int i=0;i<block;++i){
            const float impulse=(s%80==0&&i==0)?0.5f:0.0f;
            l[i]=impulse+0.03f*(float)std::sin(phase);
            r[i]=impulse+0.03f*(float)std::sin(phase*1.007);
            phase+=2.0*3.14159265358979323846*330.0/sr;
        }
        rev.process(l.data(),r.data(),block);
        for(int i=0;i<block;++i){
            finite=finite&&std::isfinite(l[i])&&std::isfinite(r[i]);
            peak=std::max(peak,(double)std::max(std::fabs(l[i]),std::fabs(r[i])));
        }
    }
    const bool pass=finite&&peak<8.0;
    std::cout<<"parameter_sweep_finite="<<finite<<" peak="<<peak<<" pass="<<pass<<"\n";
    return pass?0:1;
}
