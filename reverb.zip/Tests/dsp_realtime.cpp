#include "../Source/DSP/NxReverbEngine.hpp"
#include <atomic>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <new>
#include <vector>

static std::atomic<bool> trackAlloc{false};
static std::atomic<unsigned long long> allocCount{0};

void* operator new(std::size_t n){
    if(trackAlloc.load(std::memory_order_relaxed))allocCount.fetch_add(1,std::memory_order_relaxed);
    if(void* p=std::malloc(n))return p;
    throw std::bad_alloc();
}
void operator delete(void* p) noexcept { std::free(p); }
void* operator new[](std::size_t n){
    if(trackAlloc.load(std::memory_order_relaxed))allocCount.fetch_add(1,std::memory_order_relaxed);
    if(void* p=std::malloc(n))return p;
    throw std::bad_alloc();
}
void operator delete[](void* p) noexcept { std::free(p); }

int main(){
    constexpr int sr=48000,block=256,blocks=300;
    nx::ReverbEngine rev;
    nx::ReverbParameters p;
    p.decaySeconds=20.0f;p.modulation=1.0f;p.diffusion=1.0f;p.mix=1.0f;p.bloom=1.0f;p.spaceType=3.0f;
    rev.setParameters(p);
    rev.prepare(sr,block);
    std::vector<float> l(block),r(block);
    double phase=0.0;
    trackAlloc.store(true,std::memory_order_relaxed);
    for(int b=0;b<blocks;++b){
        for(int i=0;i<block;++i){
            l[i]=0.2f*(float)std::sin(phase);
            r[i]=0.17f*(float)std::sin(phase*1.003);
            phase+=2.0*3.14159265358979323846*117.0/sr;
        }
        rev.process(l.data(),r.data(),block);
    }
    trackAlloc.store(false,std::memory_order_relaxed);
    bool finite=true;double peak=0.0;
    for(int i=0;i<block;++i){finite=finite&&std::isfinite(l[i])&&std::isfinite(r[i]);peak=std::max(peak,(double)std::max(std::fabs(l[i]),std::fabs(r[i])));}
    const auto allocations=allocCount.load(std::memory_order_relaxed);
    const bool pass=finite&&peak<8.0&&allocations==0;
    std::cout<<"audio_thread_allocations="<<allocations<<" finite="<<finite<<" peak="<<peak<<" pass="<<pass<<"\n";
    return pass?0:1;
}
