#include "../Source/DSP/NxReverbEngine.hpp"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <vector>

static double render(int block){
    constexpr int sr=48000,n=sr*3;
    std::vector<float> l(n,0.0f),r(n,0.0f);l[0]=1.0f;r[0]=0.7f;
    nx::ReverbEngine rev; nx::ReverbParameters p; p.mix=1.0f;p.predelayMs=13.0f;p.decaySeconds=4.8f;p.bloom=0.71f;p.modulation=0.33f;
    rev.setParameters(p);rev.prepare(sr,block);
    for(int pos=0;pos<n;pos+=block)rev.process(l.data()+pos,r.data()+pos,std::min(block,n-pos));
    double e=0.0;for(int i=0;i<n;++i)e+=(double)l[i]*l[i]+(double)r[i]*r[i];return e;
}
int main(){
    const double e64=render(64),e256=render(256),e1024=render(1024);
    const double mx=std::max(e64,std::max(e256,e1024));
    const double mn=std::min(e64,std::min(e256,e1024));
    const double ratio=mx/std::max(1.0e-20,mn);
    const bool pass=std::isfinite(ratio)&&ratio<1.08;
    std::cout<<"energy64="<<e64<<" energy256="<<e256<<" energy1024="<<e1024<<" ratio="<<ratio<<" pass="<<pass<<"\n";
    return pass?0:1;
}
