# NEXUSPACE v0.2.0 Control Map

| GUI | DSP meaning | Default |
|---|---|---:|
| Space Type | Discrete ER + diffusion + FDN geometry | Hall |
| Decay | Nominal broadband late-tail RT60 target | 4.20 s |
| Predelay | Delay before wet-field input | 28 ms |
| Bloom | Delayed dense-field build-up | 62% |
| Focus | Level-aware transient rejection from late-tail injection | 70% |
| Width | Wet M/S side scaling | 120% |
| Tone | Wet low/high spectral tilt | 0 |
| Modulation | Fractional-delay movement depth | 18% |
| Mod Rate | Internal modulation speed | 0.22 Hz |
| Early Level | ER output level | -2 dB |
| Early Size | ER physical timing scale | 65% |
| Early Character | ER crossfeed and spectral character | 40% |
| Low Control | Shortens LF feedback lifetime | 50% |
| Damping | Tail HF loss | 60% |
| Diffusion | All-pass density/coefficient | 78% |
| Dry / Wet | Mix | 28% |
| Output | Plugin output trim | 0 dB |

All continuous numeric controls support exact manual entry, double-click default reset and Shift-drag fine adjustment.
