# macOS / iMac 2011 build target

NEXUSPACE targets Intel x86_64 and macOS 10.13 for the iMac 2011 compatibility line.

## Automatic GitHub build

The repository contains:

`.github/workflows/build-macos.yml`

The workflow runs automatically on every push to `main` and can also be started manually with **Actions -> NEXUSPACE macOS -> Run workflow**.

It performs this pipeline:
1. checks out the repository;
2. fetches JUCE 8.0.15 strictly as the plugin wrapper/UI dependency;
3. builds and runs the standalone custom DSP tests;
4. builds the VST3 as Intel `x86_64` with deployment target macOS 10.13;
5. verifies the produced binary architecture;
6. packages the build as the constant artifact name `NEXUSPACE-macOS.zip`;
7. uploads it under the GitHub Actions artifact name `NEXUSPACE-macOS`.

JUCE is not used for the reverb DSP. The sound engine under `Source/DSP` remains our own code.

## Local build

Use an Intel-capable macOS/Xcode toolchain and a JUCE 8.0.15 source checkout:

```bash
cmake -S . -B build \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_OSX_ARCHITECTURES=x86_64 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.13 \
  -DJUCE_DIR=/path/to/JUCE

cmake --build build --config Release --target NEXUSPACE_VST3 --parallel 4
```

## Real iMac 2011 acceptance test

A successful GitHub build is not enough to claim full compatibility. Verify the resulting VST3 on the real iMac 2011:
- plugin scan in the target DAW;
- 44.1 kHz and 48 kHz;
- 64 / 128 / 256 sample buffers;
- one, four and eight instances;
- GUI closed/open CPU comparison;
- automation, manual entry and double-click reset;
- state/preset recall;
- mono compatibility;
- long-decay stability.
