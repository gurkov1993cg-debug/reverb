# NEXUSPACE — macOS Intel build

Canonical GitHub build input:

- repo root contains `reverb.zip`
- workflow is `.github/workflows/build-macos.yml`
- workflow extracts `reverb.zip` into `project/`
- DSP tests are configured from `project/Tests`
- VST3 is configured from `project/`
- target architecture: `x86_64`
- deployment target: macOS 10.13
- JUCE is fetched only as the plugin wrapper/UI dependency
- final artifact name: `NEXUSPACE-macOS.zip`

The source ZIP name and workflow filename remain constant across revisions.
