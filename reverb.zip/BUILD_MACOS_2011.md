# NEXUSPACE — macOS Intel build

Canonical GitHub build input:

- repo root contains `reverb.zip`
- workflow is `.github/workflows/build-macos.yml`
- workflow extracts `reverb.zip` into `project/`
- DSP tests are configured from `project/Tests`
- VST3 is configured from `project/`
- target architecture: `x86_64`
- deployment target: macOS 10.13
- official Steinberg VST3 SDK 3.8.1 is fetched at pinned commit `3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96`
- VSTGUI is used only as the editor/view layer supplied with the Steinberg SDK checkout
- JUCE is not fetched, linked or included
- final artifact name: `NEXUSPACE-macOS.zip`

The source ZIP name and workflow filename remain constant across revisions.
