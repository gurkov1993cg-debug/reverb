# NEXUSPACE v0.3.0 — DSP Sound Audit

This audit checks the rendered impulse response and DSP behaviour, not only compilation.

## Result

**PASS** on the current automated sound/stability suite.

### Decay behaviour
- Default Decay: 4.2 s.
- Offline mid-band measurements are approximately 3.9–4.1 s across Hall, Chamber, Room and Cloud, depending on the measurement filter/window.
- Separate long-decay tests confirm that the mid-band decay follows 1 s, 2 s, 4.2 s, 8 s, 12 s and 20 s settings without the previous long-decay runaway problem.

### Frequency-dependent tail
At the default 4.2 s setting, the midrange remains close to nominal while bass and treble decay faster by design. This produces a controlled low end and a smoother top end without permanently low-passing the entire wet signal.

### Focus
At maximum Focus:
- early transient-fed reverb energy is reduced to about 56% of the Focus-off case;
- about 80% of the longer tail energy is retained because transient energy is deferred rather than simply discarded;
- behaviour stays essentially the same with 0 ms and 100 ms predelay, confirming the timing bug is fixed.

### Stereo / mono behaviour
- Tail stereo correlation in the audit is approximately -0.08 to -0.16 depending on space.
- The previous strongly anti-correlated projection was removed.
- Stereo remains wide without forcing the tail toward extreme anti-phase behaviour.

### Space balance
With Early Level reduced for isolation, late-tail energy spread between Hall, Chamber, Room and Cloud is about **0.33 dB**, so changing spaces no longer produces a large late-field loudness jump.

### Stability / realtime
- 44.1 kHz: PASS
- 48 kHz: PASS
- 96 kHz: PASS
- Block sizes 64 / 256 / 1024: energy ratio 1.0 in the invariance test
- Audio-thread allocations: 0
- Parameter sweep: finite / stable
- 20 s Room stress test: decay decreases; no self-build/runaway
- Current local DSP benchmark: approximately 48x realtime at 48 kHz stereo under the included benchmark. This is not an iMac 2011 benchmark.

## Important listening note
The automated audit can verify decay, spectrum, stereo behaviour, stability and rendered audio structure. Final subjective voicing still has to be auditioned in the DAW on real music and monitors; that is the next stage of sound tuning, not a replacement for these tests.
