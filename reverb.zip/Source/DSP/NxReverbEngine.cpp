#include "NxReverbEngine.hpp"
#include "NxMath.hpp"
#include <cmath>

namespace nx {
void ReverbEngine::prepare(double sampleRate, int) {
    sr_ = sampleRate;
    const std::size_t preMax = static_cast<std::size_t>(sr_ * 0.35) + 64u;
    preL_.resize(preMax); preR_.resize(preMax);
    bloomL_.resize(static_cast<std::size_t>(sr_ * 0.16) + 64u);
    bloomR_.resize(static_cast<std::size_t>(sr_ * 0.16) + 64u);
    focusL_.resize(static_cast<std::size_t>(sr_ * 0.12) + 64u);
    focusR_.resize(static_cast<std::size_t>(sr_ * 0.12) + 64u);
    focusAmt_.resize(static_cast<std::size_t>(sr_ * 0.12) + 64u);
    early_.prepare(sr_);
    for (int i=0;i<N;++i) {
        fdn_[i].resize(static_cast<std::size_t>(sr_ * 0.24) + 64u);
        hf_[i].prepare(sr_); lf_[i].prepare(sr_);
        const float ph = 2.0f * kPi * static_cast<float>(i) / static_cast<float>(N);
        sinPhase_[i] = std::sin(ph); cosPhase_[i] = std::cos(ph);
        lf_[i].setCutoff(210.0f);
    }
    for (int i=0;i<4;++i) {
        diffL_[i].prepare(sr_, 18.0f); diffR_[i].prepare(sr_, 18.0f);
        diffL_[i].set(diffProfileL_[0][i],0.58f);
        diffR_[i].set(diffProfileR_[0][i],0.58f);
    }
    transient_.prepare(sr_); toneLowL_.prepare(sr_); toneLowR_.prepare(sr_);
    focusRelease_ = std::exp(-1.0f / static_cast<float>(sr_ * 0.055));
    feedbackSlew_ = std::exp(-1.0f / static_cast<float>(sr_ * 0.020));
    feedbackGainReady_ = false;
    toneLowL_.setCutoff(1000.0f); toneLowR_.setCutoff(1000.0f);
    auto prep=[this](Smoother& s,float v){s.prepare(sr_,24.0);s.reset(v);};
    prep(decay_,target_.decaySeconds); prep(predelay_,target_.predelayMs); prep(bloom_,target_.bloom); prep(focus_,target_.focus);
    prep(width_,target_.width); prep(tone_,target_.tone); prep(modAmt_,target_.modulation); prep(modRate_,target_.modRateHz);
    prep(earlyLvl_,dbToGain(target_.earlyLevelDb)); prep(earlySize_,target_.earlySize); prep(earlyChar_,target_.earlyCharacter);
    prep(lowCtl_,target_.lowControl); prep(damping_,target_.damping); prep(diffusion_,target_.diffusion); prep(mix_,target_.mix); prep(output_,dbToGain(target_.outputDb));
    modeGate_.prepare(sr_,12.0); modeGate_.reset(1.0f);
    activeMode_=clamp(static_cast<int>(target_.spaceType+0.5f),0,3);
    pendingMode_=activeMode_; modeSwitching_=false;
    reset();
}

void ReverbEngine::reset() noexcept {
    preL_.clear(); preR_.clear(); bloomL_.clear(); bloomR_.clear(); focusL_.clear(); focusR_.clear(); focusAmt_.clear(); early_.clear(); transient_.clear();
    toneLowL_.clear(); toneLowR_.clear(); focusHold_ = 0.0f; feedbackGainReady_ = false;
    for (int i=0;i<N;++i){fdn_[i].clear(); hf_[i].clear(); lf_[i].clear();}
    for (int i=0;i<4;++i){diffL_[i].clear(); diffR_[i].clear();}
}

void ReverbEngine::hadamard(std::array<float,N>& v) noexcept {
    for (int len=1;len<N;len<<=1)
        for (int i=0;i<N;i+=(len<<1))
            for (int j=0;j<len;++j){float a=v[i+j],b=v[i+j+len];v[i+j]=a+b;v[i+j+len]=a-b;}
    constexpr float norm = 0.3535533905932738f; // 1/sqrt(8)
    for (auto& x:v) x*=norm;
}

void ReverbEngine::process(float* left, float* right, int numSamples) noexcept {
    if (numSamples <= 0 || left == nullptr || right == nullptr) return;

    decay_.setTarget(clamp(target_.decaySeconds,0.25f,20.0f)); predelay_.setTarget(clamp(target_.predelayMs,0.0f,250.0f));
    bloom_.setTarget(clamp(target_.bloom,0.0f,1.0f)); focus_.setTarget(clamp(target_.focus,0.0f,1.0f)); width_.setTarget(clamp(target_.width,0.0f,1.5f));
    tone_.setTarget(clamp(target_.tone,-1.0f,1.0f)); modAmt_.setTarget(clamp(target_.modulation,0.0f,1.0f)); modRate_.setTarget(clamp(target_.modRateHz,0.03f,1.2f));
    earlyLvl_.setTarget(dbToGain(clamp(target_.earlyLevelDb,-24.0f,6.0f))); earlySize_.setTarget(clamp(target_.earlySize,0.0f,1.0f)); earlyChar_.setTarget(clamp(target_.earlyCharacter,0.0f,1.0f));
    lowCtl_.setTarget(clamp(target_.lowControl,0.0f,1.0f)); damping_.setTarget(clamp(target_.damping,0.0f,1.0f)); diffusion_.setTarget(clamp(target_.diffusion,0.0f,1.0f));
    mix_.setTarget(clamp(target_.mix,0.0f,1.0f)); output_.setTarget(dbToGain(clamp(target_.outputDb,-24.0f,12.0f)));

    // Expensive coefficient calculations happen once per audio block, never in the
    // critical sample loop. This is intentional for older Intel Macs.
    const float dec = decay_.advance(numSamples);
    const int requestedMode=clamp(static_cast<int>(target_.spaceType+0.5f),0,3);
    if(requestedMode!=activeMode_){
        pendingMode_=requestedMode;
        modeSwitching_=true;
        modeGate_.setTarget(0.0f);
    }
    if(modeSwitching_ && modeGate_.current()<0.002f){
        reset();
        activeMode_=pendingMode_;
        modeSwitching_=false;
        modeGate_.reset(0.0f);
        modeGate_.setTarget(1.0f);
    } else if(!modeSwitching_) {
        modeGate_.setTarget(1.0f);
    }
    const int ti=activeMode_;
    early_.setSpaceType(ti);

    const float damp=damping_.advance(numSamples);
    const float hfCut=mapExp(1.0f-damp,4800.0f,15000.0f) * modeHfBias_[ti];
    const float lowCtl=lowCtl_.advance(numSamples);
    // True three-band RT60 control inside the feedback loop. At 0% the LF/HF
    // bands follow the nominal decay; increasing the controls shortens only the
    // corresponding band instead of repeatedly low-pass filtering the whole tail.
    const float lowStrength[4] = {0.75f,0.88f,1.05f,0.62f};
    const float highStrength[4]= {0.70f,0.78f,0.82f,0.65f};
    const float lowRtRatio=clamp(1.0f-lowCtl*lowStrength[ti],0.18f,1.0f);
    const float highRtRatio=clamp(1.0f-damp*highStrength[ti],0.18f,1.0f);
    const float diff=diffusion_.advance(numSamples);
    const float apg=clamp(modeDiffGain_[ti] + (diff-0.5f)*0.24f,0.38f,0.76f);
    const float earlySize=earlySize_.advance(numSamples);
    const float earlyChar=earlyChar_.advance(numSamples);
    early_.configure(earlySize,earlyChar);
    const float tv=tone_.advance(numSamples);
    const float loG=dbToGain(-3.0f*tv),hiG=dbToGain(3.0f*tv);
    const float rate=modRate_.advance(numSamples);

    std::array<float,N> fbMidGain{}, fbLowGain{}, fbHighGain{};
    std::array<float,N> oscSinInc{},oscCosInc{};
    const auto& delays = delayProfilesMs_[static_cast<std::size_t>(ti)];
    for(int i=0;i<N;++i){
        hf_[i].setCutoff(hfCut*(0.91f+0.018f*i));
        lf_[i].setCutoff(modeLfCut_[ti]*(0.94f+0.018f*i));
        const float delaySec=delays[i]*0.001f;
        const float effectiveDecay = std::max(0.25f, dec * modeDecayComp_[ti]);
        fbMidGain[i]=std::pow(10.0f,-3.0f*delaySec/effectiveDecay);
        fbLowGain[i]=std::pow(10.0f,-3.0f*delaySec/(effectiveDecay*lowRtRatio));
        fbHighGain[i]=std::pow(10.0f,-3.0f*delaySec/(effectiveDecay*highRtRatio));
        const float inc=2.0f*kPi*(rate*lineScale_[i])/static_cast<float>(sr_);
        oscSinInc[i]=std::sin(inc); oscCosInc[i]=std::cos(inc);
    }
    if(!feedbackGainReady_){ fbMidCurrent_=fbMidGain; fbLowCurrent_=fbLowGain; fbHighCurrent_=fbHighGain; feedbackGainReady_=true; }

    for(int i=0;i<4;++i){
        // Delay times stay fixed while Diffusion is moved. Moving all-pass taps
        // block-by-block creates pitchy zipper artifacts; density is controlled by g.
        diffL_[i].set(diffProfileL_[ti][i],apg);
        diffR_[i].set(diffProfileR_[ti][i],apg);
    }

    const float modeModDepth[4] = {1.00f,0.82f,0.58f,1.34f};
    const float modeTailGain[4] = {0.60f,0.56f,0.515f,0.60f};
    const float modDepthScale = modeModDepth[ti];

    // Orthogonal mid/side injection signs. The v0.1 pattern accidentally cancelled
    // mono signals at the FDN input; this basis preserves mono energy while keeping
    // stereo excitation decorrelated.
    constexpr float midSign[N]  = { 1, 1,-1,-1, 1,-1, 1,-1};
    constexpr float sideSign[N] = { 1,-1, 1,-1,-1, 1, 1,-1};

    // Fixed output projection. It is deliberately not equal to the input basis, which
    // prevents a direct-looking path through the feedback network.
    // Equal-energy, near-orthogonal output projections. The previous pair had
    // a -0.41 vector correlation and made mono input tails unnecessarily phasey.
    constexpr float outLw[N]={ 0.4799f,-0.1900f, 0.3599f, 0.2400f,-0.3199f, 0.2799f,-0.2100f, 0.3099f};
    constexpr float outRw[N]={-0.0374f, 0.4065f, 0.3775f,-0.2815f, 0.1887f, 0.5474f, 0.2149f,-0.0675f};

    for (int n=0;n<numSamples;++n) {
        const float dryL=left[n], dryR=right[n];
        const float pd = predelay_.next() * static_cast<float>(sr_ * 0.001);
        preL_.push(dryL); preR_.push(dryR);
        const float inL = pd > 1.0f ? preL_.read(pd) : dryL;
        const float inR = pd > 1.0f ? preR_.read(pd) : dryR;

        float erL=0.0f, erR=0.0f;
        early_.process(inL,inR,erL,erR);
        const float earlyGain=earlyLvl_.next(); erL*=earlyGain; erR*=earlyGain;

        float xL=inL, xR=inR;
        for (int i=0;i<4;++i){xL=diffL_[i].process(xL);xR=diffR_[i].process(xR);}

        const float bloom=bloom_.next();
        bloomL_.push(xL); bloomR_.push(xR);
        const float bloomDelayMs = 3.0f + modeBloomMs_[ti]*bloom*bloom;
        const float bloomDelay = static_cast<float>(sr_ * 0.001) * bloomDelayMs;
        const float delayedL=bloomL_.read(bloomDelay), delayedR=bloomR_.read(bloomDelay*1.037f);
        // Equal-power-ish build-up blend. Bloom delays the dense component without
        // delaying the dry signal or the first early reflections.
        const float bloomDirect = 1.0f - 0.72f*bloom;
        xL=xL*bloomDirect + delayedL*bloom;
        xR=xR*bloomDirect + delayedR*bloom;

        // Focus is intentionally detected AFTER predelay so its transient window
        // stays time-aligned with the signal entering the reverb. A short peak hold
        // keeps the dense all-pass burst from slipping through after the dry attack.
        const float tr=transient_.transient(std::max(std::fabs(inL),std::fabs(inR)));
        focusHold_=std::max(tr,focusHold_*focusRelease_);
        const float focus=focus_.next();
        const float focusDuck=focus*clamp(focusHold_*1.10f,0.0f,0.78f);

        // Do not throw transient energy away. Focus moves the sharpest part later
        // into the dense field, preserving a clean front edge while still giving
        // drums and plucks a satisfying reverb tail. This deferred-injection branch
        // is one of NEXUSPACE's signature behaviours.
        focusL_.push(xL); focusR_.push(xR); focusAmt_.push(focusDuck);
        const float focusDelayMs=7.0f+44.0f*focus;
        const float focusDelaySamples=focusDelayMs*static_cast<float>(sr_*0.001);
        const float deferredL=focusL_.read(focusDelaySamples);
        const float deferredR=focusR_.read(focusDelaySamples*1.017f);
        const float deferredDuck=clamp(focusAmt_.read(focusDelaySamples),0.0f,1.0f);
        const float deferredGain=std::sqrt(deferredDuck);
        xL=xL*(1.0f-focusDuck)+deferredL*deferredGain;
        xR=xR*(1.0f-focusDuck)+deferredR*deferredGain;

        std::array<float,N> y{};
        const float modAmt=modAmt_.next();
        for (int i=0;i<N;++i) {
            const float s=sinPhase_[i],c=cosPhase_[i];
            sinPhase_[i]=s*oscCosInc[i]+c*oscSinInc[i];
            cosPhase_[i]=c*oscCosInc[i]-s*oscSinInc[i];
            const float modMs=(0.012f+0.40f*modAmt)*modDepthScale*sinPhase_[i];
            y[i]=fdn_[i].readLinear(static_cast<float>(sr_*0.001)*(delays[i]+modMs));
        }
        std::array<float,N> mixed=y; hadamard(mixed);

        const float mid=0.5f*(xL+xR);
        const float side=0.5f*(xL-xR);
        for(int i=0;i<N;++i){
            fbMidCurrent_[i]=fbMidGain[i]+feedbackSlew_*(fbMidCurrent_[i]-fbMidGain[i]);
            fbLowCurrent_[i]=fbLowGain[i]+feedbackSlew_*(fbLowCurrent_[i]-fbLowGain[i]);
            fbHighCurrent_[i]=fbHighGain[i]+feedbackSlew_*(fbHighCurrent_[i]-fbHighGain[i]);

            // Cascaded complementary shelves: every spectral branch is attenuation-only,
            // so the feedback filter cannot create the gain overshoot that a naive
            // three-way phase-split can produce around the crossover frequencies.
            const float midGain=std::max(1.0e-6f,fbMidCurrent_[i]);
            const float lowRatio=clamp(fbLowCurrent_[i]/midGain,0.0f,1.0f);
            const float highRatio=clamp(fbHighCurrent_[i]/midGain,0.0f,1.0f);
            const float low=lf_[i].process(mixed[i]);
            const float lowShelved=mixed[i]+(lowRatio-1.0f)*low;
            const float belowHf=hf_[i].process(lowShelved);
            const float shaped=belowHf+highRatio*(lowShelved-belowHf);
            const float fb=midGain*shaped;
            const float injection=0.145f*(mid*midSign[i]+side*sideSign[i]);
            fdn_[i].push(fb+injection);
        }

        float tailL=0.0f,tailR=0.0f;
        for(int i=0;i<N;++i){tailL+=outLw[i]*y[i];tailR+=outRw[i]*y[i];}
        tailL*=modeTailGain[ti]; tailR*=modeTailGain[ti];

        float wetL=erL+tailL, wetR=erR+tailR;
        const float loL=toneLowL_.process(wetL),loR=toneLowR_.process(wetR);
        const float hiL=wetL-loL,hiR=wetR-loR;
        wetL=loL*loG+hiL*hiG; wetR=loR*loG+hiR*hiG;

        const float wetMid=0.5f*(wetL+wetR), wetSide=0.5f*(wetL-wetR)*width_.next();
        wetL=wetMid+wetSide; wetR=wetMid-wetSide;
        const float modeGate=modeGate_.next();
        wetL*=modeGate; wetR*=modeGate;
        const float mx=mix_.next(), out=output_.next();
        left[n]=(dryL*(1.0f-mx)+wetL*mx)*out;
        right[n]=(dryR*(1.0f-mx)+wetR*mx)*out;
    }

    // Recursive oscillators avoid sin() in the sample loop. Renormalising once per
    // block prevents slow amplitude drift at negligible cost.
    for(int i=0;i<N;++i){
        const float inv=1.0f/std::sqrt(std::max(1.0e-12f,sinPhase_[i]*sinPhase_[i]+cosPhase_[i]*cosPhase_[i]));
        sinPhase_[i]*=inv;cosPhase_[i]*=inv;
    }
}
}
