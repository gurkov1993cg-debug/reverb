#pragma once
#include <cmath>

namespace nx {
class Smoother {
public:
    void prepare(double sampleRate, double timeMs = 20.0) noexcept { setTime(sampleRate, timeMs); }
    void setTime(double sampleRate, double timeMs) noexcept {
        const double samples = std::max(1.0, sampleRate * timeMs * 0.001);
        coeff_ = static_cast<float>(std::exp(-1.0 / samples));
    }
    void reset(float v) noexcept { current_ = target_ = v; }
    void setTarget(float v) noexcept { target_ = v; }
    float next() noexcept { current_ = target_ + coeff_ * (current_ - target_); return current_; }
    float advance(int samples) noexcept {
        if (samples <= 0) return current_;
        current_ = target_ + std::pow(coeff_, static_cast<float>(samples)) * (current_ - target_);
        return current_;
    }
    float current() const noexcept { return current_; }
private:
    float current_ = 0.0f, target_ = 0.0f, coeff_ = 0.0f;
};
}
