#pragma once
#include "NxDelay.hpp"
#include "NxFilters.hpp"
#include <array>

namespace nx {
class EarlyReflections {
public:
    void prepare(double sr) {
        sr_ = sr;
        const auto maxS = static_cast<std::size_t>(sr * 0.45) + 32u;
        dl_.resize(maxS); dr_.resize(maxS);
        toneL_.prepare(sr); toneR_.prepare(sr);
        clear();
    }
    void clear() noexcept { dl_.clear(); dr_.clear(); toneL_.clear(); toneR_.clear(); }
    void setSpaceType(int type) noexcept { spaceType_ = clamp(type, 0, 3); }
    void configure(float size, float character) noexcept {
        size_ = clamp(size, 0.0f, 1.0f);
        character_ = clamp(character, 0.0f, 1.0f);

        // User Size scales the physical profile without making the four spaces variants
        // of the same tap pattern.
        scale_ = 0.72f + 1.15f * size_;
        const float profileCross[4] = {0.31f, 0.24f, 0.17f, 0.43f};
        const float profileTone[4]  = {0.74f, 0.63f, 0.82f, 0.92f};
        cross_ = clamp(profileCross[spaceType_] + 0.28f * character_, 0.08f, 0.72f);
        const float tone = profileTone[spaceType_] * (0.80f + 0.30f * character_);
        toneL_.setCutoff(5200.0f + 11500.0f * tone);
        toneR_.setCutoff(5000.0f + 11800.0f * tone);
    }
    void process(float inL, float inR, float& outL, float& outR) noexcept {
        dl_.push(inL); dr_.push(inR);
        const auto& times = timesMs_[static_cast<std::size_t>(spaceType_)];
        const auto& gains = gains_[static_cast<std::size_t>(spaceType_)];
        const auto& signs = polarity_[static_cast<std::size_t>(spaceType_)];
        const float scale = scale_;
        const float cross = cross_;
        const float character = character_;
        float l = 0.0f, r = 0.0f;
        for (std::size_t i=0;i<times.size();++i) {
            const float ds = static_cast<float>(sr_ * 0.001 * times[i] * scale);
            const float a = dl_.read(ds);
            const float b = dr_.read(ds * (1.0f + offsets_[i]));
            const float spectralFall = 0.94f - 0.24f * character * static_cast<float>(i) / 11.0f;
            const float amp = gains[i] * spectralFall;
            const float sign = signs[i] > 0 ? 1.0f : -1.0f;
            l += amp * (a + sign * cross * b);
            r += amp * (b - sign * cross * a);
        }
        const float norm[4] = {0.335f, 0.355f, 0.385f, 0.315f};
        outL = norm[spaceType_] * toneL_.process(l);
        outR = norm[spaceType_] * toneR_.process(r);
    }
private:
    double sr_ = 48000.0;
    FractionalDelay dl_, dr_;
    OnePoleLP toneL_, toneR_;
    int spaceType_ = 0;
    float size_=0.65f, character_=0.40f, scale_=1.4675f, cross_=0.42f;

    // Four deliberately different ER geometries. These are original tap sets,
    // chosen to avoid simple integer relationships and obvious flutter patterns.
    const std::array<std::array<float,12>,4> timesMs_{{
        {{4.1f, 7.3f, 11.8f, 17.6f, 24.9f, 33.7f, 44.8f, 57.9f, 73.6f, 92.4f, 115.1f, 142.7f}}, // Hall
        {{2.7f, 5.1f, 8.4f, 12.9f, 18.1f, 24.4f, 31.8f, 40.9f, 51.7f, 64.2f, 78.9f, 96.1f}},   // Chamber
        {{1.4f, 2.9f, 4.8f, 7.2f, 10.1f, 13.7f, 18.0f, 23.4f, 29.8f, 37.5f, 46.6f, 57.2f}},    // Room
        {{6.7f, 12.4f, 20.9f, 31.6f, 45.8f, 63.1f, 83.7f, 107.8f, 135.4f, 166.9f, 184.7f, 201.3f}} // Cloud
    }};
    const std::array<std::array<float,12>,4> gains_{{
        {{0.84f,0.75f,0.69f,0.62f,0.56f,0.50f,0.45f,0.40f,0.35f,0.31f,0.27f,0.23f}},
        {{0.88f,0.79f,0.70f,0.64f,0.57f,0.50f,0.44f,0.38f,0.33f,0.28f,0.24f,0.20f}},
        {{0.93f,0.81f,0.72f,0.63f,0.55f,0.47f,0.40f,0.34f,0.29f,0.25f,0.21f,0.18f}},
        {{0.70f,0.66f,0.62f,0.58f,0.54f,0.50f,0.47f,0.44f,0.41f,0.38f,0.35f,0.32f}}
    }};
    const std::array<std::array<int,12>,4> polarity_{{
        {{ 1,-1, 1, 1,-1, 1,-1,-1, 1,-1, 1, 1}},
        {{ 1, 1,-1, 1,-1,-1, 1,-1, 1, 1,-1, 1}},
        {{ 1,-1,-1, 1, 1,-1, 1,-1,-1, 1,-1, 1}},
        {{-1, 1, 1,-1, 1,-1,-1, 1,-1, 1, 1,-1}}
    }};
    const std::array<float,12> offsets_{{0.013f,-0.021f,0.034f,-0.017f,0.025f,-0.031f,0.019f,-0.027f,0.041f,-0.015f,0.023f,-0.037f}};
};
}
