#pragma once
#include "NxMath.hpp"
#include <cmath>

namespace nx {
class OnePoleLP {
public:
    void prepare(double sr) noexcept {
        sr_ = sr;
        smoothCoeff_ = std::exp(-1.0f / static_cast<float>(sr_ * 0.003));
        const float hz = 10000.0f;
        a_ = targetA_ = cutoffToCoeff(hz);
        clear();
    }
    void clear() noexcept { z_ = 0.0f; }
    void setCutoff(float hz) noexcept { targetA_ = cutoffToCoeff(hz); }
    float process(float x) noexcept {
        // Coefficient smoothing prevents zippering when damping/low-control are automated.
        a_ = targetA_ + smoothCoeff_ * (a_ - targetA_);
        z_ = (1.0f - a_) * x + a_ * z_;
        return z_;
    }
private:
    float cutoffToCoeff(float hz) const noexcept {
        hz = clamp(hz, 10.0f, static_cast<float>(0.45 * sr_));
        return std::exp(-2.0f * kPi * hz / static_cast<float>(sr_));
    }
    double sr_ = 48000.0;
    float a_ = 0.0f, targetA_ = 0.0f, smoothCoeff_ = 0.0f, z_ = 0.0f;
};

class EnvelopePair {
public:
    void prepare(double sr) noexcept {
        fastA_ = std::exp(-1.0f / static_cast<float>(sr * 0.0025));
        slowA_ = std::exp(-1.0f / static_cast<float>(sr * 0.045));
        clear();
    }
    void clear() noexcept { fast_ = slow_ = 0.0f; }
    float transient(float x) noexcept {
        x = std::fabs(x);
        fast_ = (1.0f-fastA_)*x + fastA_*fast_;
        slow_ = (1.0f-slowA_)*x + slowA_*slow_;
        const float excess = std::max(0.0f, fast_ - slow_);
        return excess / (fast_ + 0.005f);
    }
private:
    float fastA_=0.0f, slowA_=0.0f, fast_=0.0f, slow_=0.0f;
};
}
