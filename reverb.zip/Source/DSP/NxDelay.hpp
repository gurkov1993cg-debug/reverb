#pragma once
#include "NxMath.hpp"
#include <vector>
#include <cstddef>

namespace nx {
class FractionalDelay {
public:
    void resize(std::size_t maxSamples) {
        buffer_.assign(maxSamples + 8u, 0.0f);
        write_ = 0u;
    }
    void clear() noexcept { std::fill(buffer_.begin(), buffer_.end(), 0.0f); write_ = 0u; }
    void push(float x) noexcept {
        buffer_[write_] = x;
        if (++write_ >= buffer_.size()) write_ = 0u;
    }
    float readLinear(float delaySamples) const noexcept {
        if (buffer_.empty()) return 0.0f;
        delaySamples = clamp(delaySamples, 1.0f, static_cast<float>(buffer_.size() - 3u));
        float pos = static_cast<float>(write_) - delaySamples;
        while (pos < 0.0f) pos += static_cast<float>(buffer_.size());
        const int i0 = static_cast<int>(pos);
        const float f = pos - static_cast<float>(i0);
        const float y0 = at(i0), y1 = at(i0 + 1);
        return y0 + f * (y1 - y0);
    }
    float read(float delaySamples) const noexcept {
        if (buffer_.empty()) return 0.0f;
        delaySamples = clamp(delaySamples, 1.0f, static_cast<float>(buffer_.size() - 5u));
        float pos = static_cast<float>(write_) - delaySamples;
        while (pos < 0.0f) pos += static_cast<float>(buffer_.size());
        const int i1 = static_cast<int>(pos);
        const float f = pos - static_cast<float>(i1);
        const float y0 = at(i1 - 1), y1 = at(i1), y2 = at(i1 + 1), y3 = at(i1 + 2);
        // 4-point cubic interpolation: smooth enough for sub-ms reverb modulation, low CPU.
        const float a0 = y3 - y2 - y0 + y1;
        const float a1 = y0 - y1 - a0;
        const float a2 = y2 - y0;
        const float a3 = y1;
        return ((a0 * f + a1) * f + a2) * f + a3;
    }
private:
    float at(int idx) const noexcept {
        const int n = static_cast<int>(buffer_.size());
        while (idx < 0) idx += n;
        while (idx >= n) idx -= n;
        return buffer_[static_cast<std::size_t>(idx)];
    }
    std::vector<float> buffer_;
    std::size_t write_ = 0u;
};
}
