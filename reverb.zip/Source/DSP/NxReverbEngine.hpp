#pragma once
#include "NxAllpass.hpp"
#include "NxEarlyReflections.hpp"
#include "NxFilters.hpp"
#include "NxSmoother.hpp"
#include <array>
#include <cstddef>

namespace nx {
struct ReverbParameters {
    float spaceType = 0.0f;      // 0 Hall, 1 Chamber, 2 Room, 3 Cloud
    float decaySeconds = 4.2f;
    float predelayMs = 28.0f;
    float bloom = 0.62f;
    float focus = 0.70f;
    float width = 1.20f;
    float tone = 0.0f;           // -1..+1 => approx +/-3dB tilt
    float modulation = 0.18f;
    float modRateHz = 0.22f;
    float earlyLevelDb = -2.0f;
    float earlySize = 0.65f;
    float earlyCharacter = 0.40f;
    float lowControl = 0.50f;
    float damping = 0.60f;
    float diffusion = 0.78f;
    float mix = 0.28f;
    float outputDb = 0.0f;
};

class ReverbEngine {
public:
    void prepare(double sampleRate, int maxBlockSize);
    void reset() noexcept;
    void setParameters(const ReverbParameters& p) noexcept { target_ = p; }
    void process(float* left, float* right, int numSamples) noexcept;
private:
    static constexpr int N = 8;
    double sr_ = 48000.0;
    ReverbParameters target_{};
    EarlyReflections early_;
    FractionalDelay preL_, preR_, bloomL_, bloomR_, focusL_, focusR_, focusAmt_;
    std::array<FractionalDelay,N> fdn_;
    std::array<OnePoleLP,N> hf_;
    std::array<OnePoleLP,N> lf_;
    std::array<float,N> sinPhase_{};
    std::array<float,N> fbMidCurrent_{};
    std::array<float,N> fbLowCurrent_{};
    std::array<float,N> fbHighCurrent_{};
    std::array<float,N> cosPhase_{};
    std::array<float,N> lineScale_{{1.00f,1.11f,0.93f,1.19f,1.27f,0.87f,1.36f,1.07f}};

    // Each mode has a genuinely different late-field geometry, not a scale factor.
    const std::array<std::array<float,N>,4> delayProfilesMs_{{
        {{37.1f, 43.7f, 51.1f, 59.3f, 68.9f, 79.7f, 92.3f, 107.9f}}, // Hall
        {{23.9f, 29.7f, 35.3f, 41.9f, 49.1f, 57.7f, 67.1f, 78.1f}},  // Chamber
        {{13.7f, 17.9f, 22.3f, 27.1f, 32.9f, 39.7f, 47.3f, 56.9f}},  // Room
        {{48.7f, 61.3f, 75.1f, 91.7f, 109.3f, 128.9f, 151.1f, 176.3f}} // Cloud
    }};
    const std::array<std::array<float,4>,4> diffProfileL_{{
        {{2.11f,3.73f,5.83f,8.47f}}, {{1.57f,2.71f,4.13f,6.17f}},
        {{0.93f,1.61f,2.47f,3.71f}}, {{3.17f,5.23f,7.91f,11.87f}}
    }};
    const std::array<std::array<float,4>,4> diffProfileR_{{
        {{2.47f,4.19f,6.31f,9.11f}}, {{1.83f,3.07f,4.61f,6.79f}},
        {{1.09f,1.87f,2.83f,4.19f}}, {{3.71f,5.89f,8.83f,13.21f}}
    }};
    const std::array<float,4> modeDiffGain_{{0.61f,0.57f,0.49f,0.68f}};
    const std::array<float,4> modeHfBias_{{0.94f,0.88f,1.05f,0.82f}};
    const std::array<float,4> modeLfCut_{{210.0f,240.0f,285.0f,165.0f}};
    const std::array<float,4> modeBloomMs_{{72.0f,46.0f,24.0f,104.0f}};
    // Compensates for interpolation + damping losses so the user Decay control
    // tracks the measured mid-band RT60 much more closely in every space.
    const std::array<float,4> modeDecayComp_{{1.05f,1.07f,1.10f,1.03f}};

    std::array<Allpass,4> diffL_, diffR_;
    EnvelopePair transient_;
    OnePoleLP toneLowL_, toneLowR_;
    Smoother decay_, predelay_, bloom_, focus_, width_, tone_, modAmt_, modRate_, earlyLvl_, earlySize_, earlyChar_, lowCtl_, damping_, diffusion_, mix_, output_, modeGate_;
    float focusHold_ = 0.0f;
    float focusRelease_ = 0.0f;
    float feedbackSlew_ = 0.0f;
    bool feedbackGainReady_ = false;
    int activeMode_ = 0;
    int pendingMode_ = 0;
    bool modeSwitching_ = false;
    void hadamard(std::array<float,N>& v) noexcept;
};
}
