#pragma once
#include <algorithm>
#include <cmath>

namespace nx {
constexpr float kPi = 3.14159265358979323846f;

template <typename T>
inline T clamp(T v, T lo, T hi) noexcept { return std::max(lo, std::min(v, hi)); }

inline float dbToGain(float db) noexcept { return std::pow(10.0f, db / 20.0f); }
inline float gainToDb(float g) noexcept { return 20.0f * std::log10(std::max(g, 1.0e-9f)); }
inline float lerp(float a, float b, float t) noexcept { return a + (b - a) * t; }

inline float mapExp(float t, float lo, float hi) noexcept {
    t = clamp(t, 0.0f, 1.0f);
    return lo * std::pow(hi / lo, t);
}
}
