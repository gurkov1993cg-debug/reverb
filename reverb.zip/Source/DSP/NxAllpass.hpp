#pragma once
#include "NxDelay.hpp"
#include <cmath>

namespace nx {
class Allpass {
public:
    void prepare(double sr, float maxMs = 20.0f) {
        sr_ = sr;
        delay_.resize(static_cast<std::size_t>(sr * maxMs * 0.001) + 16u);
        gainSlew_ = std::exp(-1.0f / static_cast<float>(sr_ * 0.004));
        firstSet_ = true;
    }
    void clear() noexcept { delay_.clear(); }
    void set(float ms, float g) noexcept {
        delaySamples_ = static_cast<float>(sr_ * ms * 0.001);
        gTarget_ = clamp(g, 0.0f, 0.82f);
        if (firstSet_) { g_ = gTarget_; firstSet_ = false; }
    }
    float process(float x) noexcept {
        g_ = gTarget_ + gainSlew_ * (g_ - gTarget_);
        const float d = delay_.read(delaySamples_);
        const float y = -g_ * x + d;
        delay_.push(x + g_ * y);
        return y;
    }
private:
    double sr_ = 48000.0;
    float delaySamples_ = 10.0f, g_ = 0.5f, gTarget_ = 0.5f, gainSlew_ = 0.0f;
    bool firstSet_ = true;
    FractionalDelay delay_;
};
}
