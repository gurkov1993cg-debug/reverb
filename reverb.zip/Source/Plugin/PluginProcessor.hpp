#pragma once

#include "public.sdk/source/vst/vstaudioeffect.h"
#include "NxParameter.hpp"
#include "../DSP/NxReverbEngine.hpp"

#include <array>

namespace nexuspace {

class Processor final : public Steinberg::Vst::AudioEffect {
public:
    Processor();
    ~Processor() SMTG_OVERRIDE = default;

    static Steinberg::FUnknown* createInstance(void*) {
        return static_cast<Steinberg::Vst::IAudioProcessor*>(new Processor());
    }

    Steinberg::tresult PLUGIN_API initialize(Steinberg::FUnknown* context) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setBusArrangements(Steinberg::Vst::SpeakerArrangement* inputs,
                                                      Steinberg::int32 numIns,
                                                      Steinberg::Vst::SpeakerArrangement* outputs,
                                                      Steinberg::int32 numOuts) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API canProcessSampleSize(Steinberg::int32 symbolicSampleSize) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setupProcessing(Steinberg::Vst::ProcessSetup& setup) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setActive(Steinberg::TBool state) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API process(Steinberg::Vst::ProcessData& data) SMTG_OVERRIDE;
    Steinberg::uint32 PLUGIN_API getTailSamples() SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API setState(Steinberg::IBStream* state) SMTG_OVERRIDE;
    Steinberg::tresult PLUGIN_API getState(Steinberg::IBStream* state) SMTG_OVERRIDE;

private:
    nx::ReverbEngine engine_;
    std::array<double, nxp::kParamCount> normalized_ {};
    double sampleRate_ {48000.0};

    void resetDefaults() noexcept;
    void readParameterChanges(Steinberg::Vst::IParameterChanges* changes) noexcept;
    nx::ReverbParameters makeParameters() const noexcept;
    void publishMeters(Steinberg::Vst::IParameterChanges* changes,
                       float inL, float inR, float outL, float outR) noexcept;
};

} // namespace nexuspace
