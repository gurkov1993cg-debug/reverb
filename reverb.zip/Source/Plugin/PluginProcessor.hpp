#pragma once
#include <JuceHeader.h>
#include "NxParameter.hpp"
#include "../DSP/NxReverbEngine.hpp"
#include <array>
#include <atomic>

class NexuspaceAudioProcessor final : public juce::AudioProcessor {
public:
    enum ParamIndex { SpaceType,Decay,Predelay,Bloom,Focus,Width,Tone,ModAmount,ModRate,EarlyLevel,EarlySize,EarlyCharacter,LowControl,Damping,Diffusion,Mix,Output,ParamCount };
    NexuspaceAudioProcessor();
    ~NexuspaceAudioProcessor() override = default;
    void prepareToPlay(double,int) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported(const BusesLayout&) const override;
    void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "NEXUSPACE"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return params_[Decay]->actual()+0.5; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int,const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*,int) override;
    nxp::Parameter& param(int index) noexcept { return *params_[static_cast<std::size_t>(index)]; }
    const nxp::Parameter& param(int index) const noexcept { return *params_[static_cast<std::size_t>(index)]; }
    float inputPeakL() const noexcept { return inPeakL_.load(); }
    float inputPeakR() const noexcept { return inPeakR_.load(); }
    float outputPeakL() const noexcept { return outPeakL_.load(); }
    float outputPeakR() const noexcept { return outPeakR_.load(); }
private:
    nx::ReverbEngine engine_;
    std::array<nxp::Parameter*,ParamCount> params_{};
    std::atomic<float> inPeakL_{0},inPeakR_{0},outPeakL_{0},outPeakR_{0};
    nx::ReverbParameters readParameters() const noexcept;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(NexuspaceAudioProcessor)
};
