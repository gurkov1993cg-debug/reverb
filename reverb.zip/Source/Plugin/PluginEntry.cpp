#include "PluginProcessor.hpp"
#include "PluginController.hpp"
#include "PluginIDs.hpp"

#include "public.sdk/source/main/pluginfactory.h"

using namespace Steinberg;
using namespace Steinberg::Vst;

BEGIN_FACTORY_DEF(nexuspace::kCompanyName, nexuspace::kCompanyWeb, nexuspace::kCompanyEmail)

DEF_CLASS2(INLINE_UID_FROM_FUID(nexuspace::kProcessorUID),
           PClassInfo::kManyInstances,
           kVstAudioEffectClass,
           nexuspace::kPluginName,
           Vst::kDistributable,
           "Fx|Reverb",
           nexuspace::kPluginVersion,
           kVstVersionString,
           nexuspace::Processor::createInstance)

DEF_CLASS2(INLINE_UID_FROM_FUID(nexuspace::kControllerUID),
           PClassInfo::kManyInstances,
           kVstComponentControllerClass,
           "NEXUSPACE Controller",
           0,
           "",
           nexuspace::kPluginVersion,
           kVstVersionString,
           nexuspace::Controller::createInstance)

END_FACTORY
