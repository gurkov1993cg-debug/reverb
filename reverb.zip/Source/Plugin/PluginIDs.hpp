#pragma once
#include "pluginterfaces/base/funknown.h"

namespace nexuspace {

static const Steinberg::FUID kProcessorUID (0x3F37B5C5, 0x4EF24B5E, 0xAD2CF066, 0xD9EEEDE8);
static const Steinberg::FUID kControllerUID(0xE30687AE, 0x38E443F5, 0x8CD19B1A, 0x401E6838);

constexpr const char* kPluginName = "NEXUSPACE";
constexpr const char* kCompanyName = "VETRA AUDIO";
constexpr const char* kCompanyWeb = "";
constexpr const char* kCompanyEmail = "";
constexpr const char* kPluginVersion = "0.4.0";

} // namespace nexuspace
