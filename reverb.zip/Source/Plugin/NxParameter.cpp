#include "NxParameter.hpp"
#include <cstring>

namespace nxp {
float Parameter::quantizeActual(float v) const noexcept {
    v=juce::jlimit(spec_.minValue,spec_.maxValue,v);
    if(spec_.discreteSteps>1){
        const float steps=static_cast<float>(spec_.discreteSteps-1);
        const float n=(v-spec_.minValue)/(spec_.maxValue-spec_.minValue);
        v=spec_.minValue+std::round(n*steps)*(spec_.maxValue-spec_.minValue)/steps;
    }
    return v;
}
float Parameter::toNorm(float v) const noexcept {
    v=quantizeActual(v);
    if(spec_.skewed && spec_.minValue>0.0f)
        return std::log(v/spec_.minValue)/std::log(spec_.maxValue/spec_.minValue);
    return (v-spec_.minValue)/(spec_.maxValue-spec_.minValue);
}
float Parameter::fromNorm(float n) const noexcept {
    n=juce::jlimit(0.0f,1.0f,n);
    float v=0.0f;
    if(spec_.skewed && spec_.minValue>0.0f)
        v=spec_.minValue*std::pow(spec_.maxValue/spec_.minValue,n);
    else
        v=spec_.minValue+n*(spec_.maxValue-spec_.minValue);
    return quantizeActual(v);
}
juce::String Parameter::getText(float normalized,int) const {
    const float v=fromNorm(normalized);
    if(std::strcmp(spec_.id,"space")==0){
        static const char* names[4]={"Hall","Chamber","Room","Cloud"};
        return names[juce::jlimit(0,3,static_cast<int>(std::round(v)))];
    }
    if(std::strcmp(spec_.unit,"ms")==0) return juce::String(v,1)+" ms";
    if(std::strcmp(spec_.unit,"s")==0) return juce::String(v,2)+" s";
    if(std::strcmp(spec_.unit,"Hz")==0) return juce::String(v,2)+" Hz";
    if(std::strcmp(spec_.unit,"dB")==0) return juce::String(v,1)+" dB";
    if(std::strcmp(spec_.unit,"%")==0) return juce::String(v*100.0f,0)+" %";
    return juce::String(v,3);
}
float Parameter::getValueForText(const juce::String& text) const {
    if(std::strcmp(spec_.id,"space")==0){
        const auto t=text.trim().toLowerCase();
        if(t.startsWith("hall")) return toNorm(0.0f);
        if(t.startsWith("chamber")) return toNorm(1.0f);
        if(t.startsWith("room")) return toNorm(2.0f);
        if(t.startsWith("cloud")) return toNorm(3.0f);
    }
    auto cleaned=text.retainCharacters("-0123456789.,").replaceCharacter(',', '.');
    const float v=cleaned.getFloatValue();
    return toNorm((std::strcmp(spec_.unit,"%")==0)?v*0.01f:v);
}
}
