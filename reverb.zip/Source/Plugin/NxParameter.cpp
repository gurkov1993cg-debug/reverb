#include "NxParameter.hpp"

namespace nxp {

namespace {
void setAscii(Steinberg::Vst::String128 dst, const char* text) {
    Steinberg::UString(dst, 128).fromAscii(text ? text : "");
}
}

NxRangeParameter::NxRangeParameter(const ParamSpec& spec) : spec_(spec) {
    setAscii(info.title, spec.name);
    setAscii(info.shortTitle, spec.name);
    setAscii(info.units, spec.unit);
    info.id = spec.id;
    info.stepCount = spec.valueCount > 1 ? spec.valueCount - 1 : Steinberg::Vst::kStepCountContinuous;
    info.defaultNormalizedValue = nxp::toNormalized(spec_, spec_.defaultValue);
    info.unitId = Steinberg::Vst::kRootUnitId;
    info.flags = Steinberg::Vst::ParameterInfo::kCanAutomate;
    setNormalized(info.defaultNormalizedValue);
}

void NxRangeParameter::toString(ParamValue normalized, Steinberg::Vst::String128 string) const {
    const double v = nxp::fromNormalized(spec_, normalized);
    char text[64] {};
    if (std::strcmp(spec_.unit, "%") == 0)
        std::snprintf(text, sizeof(text), "%.0f %%", v * 100.0);
    else if (std::strcmp(spec_.unit, "ms") == 0)
        std::snprintf(text, sizeof(text), "%.1f ms", v);
    else if (std::strcmp(spec_.unit, "s") == 0)
        std::snprintf(text, sizeof(text), "%.2f s", v);
    else if (std::strcmp(spec_.unit, "Hz") == 0)
        std::snprintf(text, sizeof(text), "%.2f Hz", v);
    else if (std::strcmp(spec_.unit, "dB") == 0)
        std::snprintf(text, sizeof(text), "%.1f dB", v);
    else
        std::snprintf(text, sizeof(text), "%.3f", v);
    Steinberg::UString(string, 128).fromAscii(text);
}

bool NxRangeParameter::fromString(const Steinberg::Vst::TChar* string, ParamValue& normalized) const {
    if (!string) return false;
    Steinberg::String wrapper(const_cast<Steinberg::Vst::TChar*>(string));
    double value = 0.0;
    if (!wrapper.scanFloat(value)) return false;
    if (std::strcmp(spec_.unit, "%") == 0) value *= 0.01;
    normalized = nxp::toNormalized(spec_, value);
    return true;
}

ParamValue NxRangeParameter::toPlain(ParamValue normalized) const {
    return nxp::fromNormalized(spec_, normalized);
}

ParamValue NxRangeParameter::toNormalized(ParamValue plain) const {
    return nxp::toNormalized(spec_, plain);
}

Steinberg::Vst::Parameter* createParameter(const ParamSpec& spec) {
    if (spec.id == kSpaceType) {
        auto* p = new Steinberg::Vst::StringListParameter(STR16("Space Type"), spec.id);
        Steinberg::Vst::String128 s {};
        setAscii(s, "Hall");    p->appendString(s);
        setAscii(s, "Chamber"); p->appendString(s);
        setAscii(s, "Room");    p->appendString(s);
        setAscii(s, "Cloud");   p->appendString(s);
        p->setNormalized(nxp::toNormalized(spec, spec.defaultValue));
        return p;
    }
    return new NxRangeParameter(spec);
}

} // namespace nxp
