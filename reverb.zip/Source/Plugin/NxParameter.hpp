#pragma once

#include "public.sdk/source/vst/vstparameters.h"
#include "pluginterfaces/base/ustring.h"
#include "base/source/fstring.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>

namespace nxp {

using Steinberg::Vst::ParamID;
using Steinberg::Vst::ParamValue;

struct ParamSpec {
    ParamID id;
    const char* key;
    const char* name;
    const char* unit;
    float minValue;
    float maxValue;
    float defaultValue;
    bool skewed;
    int valueCount; // 0 = continuous, otherwise discrete value count
};

enum ParamIds : ParamID {
    kSpaceType = 0,
    kDecay,
    kPredelay,
    kBloom,
    kFocus,
    kWidth,
    kTone,
    kModAmount,
    kModRate,
    kEarlyLevel,
    kEarlySize,
    kEarlyCharacter,
    kLowControl,
    kDamping,
    kDiffusion,
    kMix,
    kOutput,
    kParamCount,

    kInputPeakL = 100,
    kInputPeakR,
    kOutputPeakL,
    kOutputPeakR
};

inline constexpr std::array<ParamSpec, kParamCount> kSpecs {{
    {kSpaceType,     "space",      "Space Type",      "",   0.0f,   3.0f,   0.0f,  false, 4},
    {kDecay,         "decay",      "Decay",           "s",  0.25f, 20.0f,   4.2f,  true,  0},
    {kPredelay,      "predelay",   "Predelay",        "ms", 0.0f, 250.0f,  28.0f,  false, 0},
    {kBloom,         "bloom",      "Bloom",           "%",  0.0f,   1.0f,   0.62f, false, 0},
    {kFocus,         "focus",      "Focus",           "%",  0.0f,   1.0f,   0.70f, false, 0},
    {kWidth,         "width",      "Width",           "%",  0.0f,   1.5f,   1.20f, false, 0},
    {kTone,          "tone",       "Tone",            "",  -1.0f,   1.0f,   0.0f,  false, 0},
    {kModAmount,     "modamt",     "Modulation",      "%",  0.0f,   1.0f,   0.18f, false, 0},
    {kModRate,       "modrate",    "Mod Rate",        "Hz", 0.03f,  1.2f,   0.22f, true,  0},
    {kEarlyLevel,    "earlylvl",   "Early Level",     "dB",-24.0f,  6.0f,  -2.0f,  false, 0},
    {kEarlySize,     "earlysize",  "Early Size",      "%",  0.0f,   1.0f,   0.65f, false, 0},
    {kEarlyCharacter,"earlychar",  "Early Character", "%",  0.0f,   1.0f,   0.40f, false, 0},
    {kLowControl,    "lowctl",     "Low Control",     "%",  0.0f,   1.0f,   0.50f, false, 0},
    {kDamping,       "damping",    "Damping",         "%",  0.0f,   1.0f,   0.60f, false, 0},
    {kDiffusion,     "diffusion",  "Diffusion",       "%",  0.0f,   1.0f,   0.78f, false, 0},
    {kMix,           "mix",        "Dry / Wet",       "%",  0.0f,   1.0f,   0.28f, false, 0},
    {kOutput,        "output",     "Output",          "dB",-24.0f, 12.0f,   0.0f,  false, 0}
}};

inline const ParamSpec* specFor(ParamID id) noexcept {
    return id < kParamCount ? &kSpecs[static_cast<std::size_t>(id)] : nullptr;
}

inline double clamp01(double v) noexcept { return std::max(0.0, std::min(1.0, v)); }

inline double quantizeActual(const ParamSpec& s, double v) noexcept {
    v = std::max<double>(s.minValue, std::min<double>(s.maxValue, v));
    if (s.valueCount > 1) {
        const double steps = static_cast<double>(s.valueCount - 1);
        const double n = (v - s.minValue) / (s.maxValue - s.minValue);
        v = s.minValue + std::round(n * steps) * (s.maxValue - s.minValue) / steps;
    }
    return v;
}

inline double toNormalized(const ParamSpec& s, double actual) noexcept {
    actual = quantizeActual(s, actual);
    if (s.skewed && s.minValue > 0.0f)
        return clamp01(std::log(actual / s.minValue) / std::log(s.maxValue / s.minValue));
    return clamp01((actual - s.minValue) / (s.maxValue - s.minValue));
}

inline double fromNormalized(const ParamSpec& s, double normalized) noexcept {
    normalized = clamp01(normalized);
    double actual = 0.0;
    if (s.skewed && s.minValue > 0.0f)
        actual = s.minValue * std::pow(s.maxValue / s.minValue, normalized);
    else
        actual = s.minValue + normalized * (s.maxValue - s.minValue);
    return quantizeActual(s, actual);
}

class NxRangeParameter final : public Steinberg::Vst::Parameter {
public:
    explicit NxRangeParameter(const ParamSpec& spec);

    void toString(ParamValue normalized, Steinberg::Vst::String128 string) const SMTG_OVERRIDE;
    bool fromString(const Steinberg::Vst::TChar* string, ParamValue& normalized) const SMTG_OVERRIDE;
    ParamValue toPlain(ParamValue normalized) const SMTG_OVERRIDE;
    ParamValue toNormalized(ParamValue plain) const SMTG_OVERRIDE;

private:
    ParamSpec spec_;
};

Steinberg::Vst::Parameter* createParameter(const ParamSpec& spec);

} // namespace nxp
