#pragma once
#include <JuceHeader.h>
#include <atomic>
#include <cmath>

namespace nxp {
struct ParamSpec {
    const char* id;
    const char* name;
    const char* unit;
    float minValue;
    float maxValue;
    float defaultValue;
    bool skewed;
    int discreteSteps; // 0 = continuous, otherwise number of equally spaced values
};

class Parameter final : public juce::AudioProcessorParameter {
public:
    explicit Parameter(ParamSpec spec) : spec_(spec), value_(spec.defaultValue) {}
    float getValue() const override { return toNorm(value_.load(std::memory_order_relaxed)); }
    void setValue(float newValue) override { value_.store(fromNorm(newValue), std::memory_order_relaxed); }
    float getDefaultValue() const override { return toNorm(spec_.defaultValue); }
    juce::String getName(int maxLen) const override { return juce::String(spec_.name).substring(0,maxLen); }
    juce::String getLabel() const override { return spec_.unit; }
    int getNumSteps() const override { return spec_.discreteSteps > 1 ? spec_.discreteSteps : juce::AudioProcessorParameter::getDefaultNumParameterSteps(); }
    bool isDiscrete() const override { return spec_.discreteSteps > 1; }
    bool isBoolean() const override { return spec_.discreteSteps == 2; }
    bool isAutomatable() const override { return true; }
    bool isMetaParameter() const override { return false; }
    juce::String getText(float normalized, int) const override;
    float getValueForText(const juce::String& text) const override;
    juce::String getParameterID() const { return spec_.id; }
    float actual() const noexcept { return value_.load(std::memory_order_relaxed); }
    float minimum() const noexcept { return spec_.minValue; }
    float maximum() const noexcept { return spec_.maxValue; }
    float defaultActual() const noexcept { return spec_.defaultValue; }
    void setActualNotifyingHost(float v) { setValueNotifyingHost(toNorm(v)); }
    float toNorm(float v) const noexcept;
    float fromNorm(float n) const noexcept;
private:
    float quantizeActual(float v) const noexcept;
    ParamSpec spec_;
    std::atomic<float> value_;
};
}
