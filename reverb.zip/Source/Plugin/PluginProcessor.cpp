#include "PluginProcessor.hpp"
#include "PluginEditor.hpp"
#include <cstring>

namespace {
using nxp::ParamSpec;
constexpr ParamSpec specs[NexuspaceAudioProcessor::ParamCount] = {
    {"space","Space Type","",0,3,0,false,4},
    {"decay","Decay","s",0.25f,20.0f,4.2f,true,0},
    {"predelay","Predelay","ms",0,250,28,false,0},
    {"bloom","Bloom","%",0,1,0.62f,false,0},
    {"focus","Focus","%",0,1,0.70f,false,0},
    {"width","Width","%",0,1.5f,1.20f,false,0},
    {"tone","Tone","",-1,1,0,false,0},
    {"modamt","Modulation","%",0,1,0.18f,false,0},
    {"modrate","Mod Rate","Hz",0.03f,1.2f,0.22f,true,0},
    {"earlylvl","Early Level","dB",-24,6,-2,false,0},
    {"earlysize","Early Size","%",0,1,0.65f,false,0},
    {"earlychar","Early Character","%",0,1,0.40f,false,0},
    {"lowctl","Low Control","%",0,1,0.50f,false,0},
    {"damping","Damping","%",0,1,0.60f,false,0},
    {"diffusion","Diffusion","%",0,1,0.78f,false,0},
    {"mix","Dry / Wet","%",0,1,0.28f,false,0},
    {"output","Output","dB",-24,12,0,false,0}
};
struct StateHeader { char magic[4]; uint32_t version; uint32_t count; };
}

NexuspaceAudioProcessor::NexuspaceAudioProcessor()
: juce::AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)) {
    for(int i=0;i<ParamCount;++i){ auto* p=new nxp::Parameter(specs[i]); params_[static_cast<std::size_t>(i)]=p; addParameter(p); }
}
void NexuspaceAudioProcessor::prepareToPlay(double sr,int block){ engine_.setParameters(readParameters()); engine_.prepare(sr,block); }
bool NexuspaceAudioProcessor::isBusesLayoutSupported(const BusesLayout& l) const { return l.getMainInputChannelSet()==juce::AudioChannelSet::stereo() && l.getMainOutputChannelSet()==juce::AudioChannelSet::stereo(); }
nx::ReverbParameters NexuspaceAudioProcessor::readParameters() const noexcept {
    nx::ReverbParameters p; p.spaceType=param(SpaceType).actual();p.decaySeconds=param(Decay).actual();p.predelayMs=param(Predelay).actual();p.bloom=param(Bloom).actual();p.focus=param(Focus).actual();p.width=param(Width).actual();p.tone=param(Tone).actual();p.modulation=param(ModAmount).actual();p.modRateHz=param(ModRate).actual();p.earlyLevelDb=param(EarlyLevel).actual();p.earlySize=param(EarlySize).actual();p.earlyCharacter=param(EarlyCharacter).actual();p.lowControl=param(LowControl).actual();p.damping=param(Damping).actual();p.diffusion=param(Diffusion).actual();p.mix=param(Mix).actual();p.outputDb=param(Output).actual();return p;
}
void NexuspaceAudioProcessor::processBlock(juce::AudioBuffer<float>& b,juce::MidiBuffer&){ juce::ScopedNoDenormals noDenormals; if(b.getNumChannels()<2)return; auto* l=b.getWritePointer(0);auto* r=b.getWritePointer(1);float il=0,ir=0;for(int i=0;i<b.getNumSamples();++i){il=std::max(il,std::abs(l[i]));ir=std::max(ir,std::abs(r[i]));}inPeakL_.store(il);inPeakR_.store(ir);engine_.setParameters(readParameters());engine_.process(l,r,b.getNumSamples());float ol=0,orr=0;for(int i=0;i<b.getNumSamples();++i){ol=std::max(ol,std::abs(l[i]));orr=std::max(orr,std::abs(r[i]));}outPeakL_.store(ol);outPeakR_.store(orr); }
juce::AudioProcessorEditor* NexuspaceAudioProcessor::createEditor(){ return new NexuspaceAudioProcessorEditor(*this); }
void NexuspaceAudioProcessor::getStateInformation(juce::MemoryBlock& dest){ StateHeader h{{'N','X','S','P'},1,ParamCount}; dest.setSize(sizeof(h)+sizeof(float)*ParamCount); auto* p=static_cast<char*>(dest.getData());std::memcpy(p,&h,sizeof(h));p+=sizeof(h);for(int i=0;i<ParamCount;++i){float v=param(i).actual();std::memcpy(p,&v,sizeof(v));p+=sizeof(v);} }
void NexuspaceAudioProcessor::setStateInformation(const void* data,int size){ if(size<(int)sizeof(StateHeader))return;StateHeader h{};std::memcpy(&h,data,sizeof(h));if(std::memcmp(h.magic,"NXSP",4)!=0||h.version!=1||h.count!=ParamCount||size<(int)(sizeof(h)+sizeof(float)*ParamCount))return;auto* p=static_cast<const char*>(data)+sizeof(h);for(int i=0;i<ParamCount;++i){float v;std::memcpy(&v,p,sizeof(v));p+=sizeof(v);param(i).setActualNotifyingHost(v);} }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){ return new NexuspaceAudioProcessor(); }
