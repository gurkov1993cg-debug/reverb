#include "PluginProcessor.hpp"
#include "PluginIDs.hpp"

#include "base/source/fstreamer.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"

#include <algorithm>
#include <cmath>
#include <cstring>
#if defined(__SSE__) || defined(_M_X64) || defined(_M_IX86)
#include <xmmintrin.h>
#endif

namespace nexuspace {

namespace {
constexpr Steinberg::uint32 kStateMagic = 0x5053584Eu; // NXSP in little endian stream bytes
constexpr Steinberg::int32 kStateVersion = 2;

class ScopedDenormalGuard {
public:
    ScopedDenormalGuard() noexcept {
#if defined(__SSE__) || defined(_M_X64) || defined(_M_IX86)
        old_ = _mm_getcsr();
        _mm_setcsr(old_ | 0x8040u); // FTZ + DAZ
#endif
    }
    ~ScopedDenormalGuard() noexcept {
#if defined(__SSE__) || defined(_M_X64) || defined(_M_IX86)
        _mm_setcsr(old_);
#endif
    }
private:
#if defined(__SSE__) || defined(_M_X64) || defined(_M_IX86)
    unsigned int old_ {0};
#endif
};

inline float peakOf(const float* data, Steinberg::int32 count) noexcept {
    float p = 0.0f;
    for (Steinberg::int32 i = 0; i < count; ++i) p = std::max(p, std::fabs(data[i]));
    return p;
}
}

Processor::Processor() {
    setControllerClass(kControllerUID);
    resetDefaults();
}

void Processor::resetDefaults() noexcept {
    for (const auto& s : nxp::kSpecs)
        normalized_[static_cast<std::size_t>(s.id)] = nxp::toNormalized(s, s.defaultValue);
}

Steinberg::tresult PLUGIN_API Processor::initialize(Steinberg::FUnknown* context) {
    auto result = AudioEffect::initialize(context);
    if (result != Steinberg::kResultOk) return result;
    addAudioInput(STR16("Stereo Input"), Steinberg::Vst::SpeakerArr::kStereo);
    addAudioOutput(STR16("Stereo Output"), Steinberg::Vst::SpeakerArr::kStereo);
    return Steinberg::kResultOk;
}

Steinberg::tresult PLUGIN_API Processor::setBusArrangements(
    Steinberg::Vst::SpeakerArrangement* inputs, Steinberg::int32 numIns,
    Steinberg::Vst::SpeakerArrangement* outputs, Steinberg::int32 numOuts) {
    if (numIns == 1 && numOuts == 1 &&
        inputs[0] == Steinberg::Vst::SpeakerArr::kStereo &&
        outputs[0] == Steinberg::Vst::SpeakerArr::kStereo)
        return AudioEffect::setBusArrangements(inputs, numIns, outputs, numOuts);
    return Steinberg::kResultFalse;
}

Steinberg::tresult PLUGIN_API Processor::canProcessSampleSize(Steinberg::int32 symbolicSampleSize) {
    return symbolicSampleSize == Steinberg::Vst::kSample32 ? Steinberg::kResultTrue : Steinberg::kResultFalse;
}

Steinberg::tresult PLUGIN_API Processor::setupProcessing(Steinberg::Vst::ProcessSetup& setup) {
    auto result = AudioEffect::setupProcessing(setup);
    if (result != Steinberg::kResultOk) return result;
    sampleRate_ = setup.sampleRate;
    engine_.setParameters(makeParameters());
    engine_.prepare(setup.sampleRate, setup.maxSamplesPerBlock);
    return Steinberg::kResultOk;
}

Steinberg::tresult PLUGIN_API Processor::setActive(Steinberg::TBool state) {
    if (state) engine_.reset();
    return AudioEffect::setActive(state);
}

void Processor::readParameterChanges(Steinberg::Vst::IParameterChanges* changes) noexcept {
    if (!changes) return;
    const auto count = changes->getParameterCount();
    for (Steinberg::int32 i = 0; i < count; ++i) {
        auto* queue = changes->getParameterData(i);
        if (!queue) continue;
        const auto id = queue->getParameterId();
        if (id >= nxp::kParamCount) continue;
        const auto points = queue->getPointCount();
        if (points <= 0) continue;
        Steinberg::int32 sampleOffset = 0;
        Steinberg::Vst::ParamValue value = 0.0;
        if (queue->getPoint(points - 1, sampleOffset, value) == Steinberg::kResultTrue)
            normalized_[static_cast<std::size_t>(id)] = nxp::clamp01(value);
    }
}

nx::ReverbParameters Processor::makeParameters() const noexcept {
    auto actual = [this](nxp::ParamID id) -> float {
        const auto& s = nxp::kSpecs[static_cast<std::size_t>(id)];
        return static_cast<float>(nxp::fromNormalized(s, normalized_[static_cast<std::size_t>(id)]));
    };
    nx::ReverbParameters p;
    p.spaceType       = actual(nxp::kSpaceType);
    p.decaySeconds    = actual(nxp::kDecay);
    p.predelayMs      = actual(nxp::kPredelay);
    p.bloom           = actual(nxp::kBloom);
    p.focus           = actual(nxp::kFocus);
    p.width           = actual(nxp::kWidth);
    p.tone            = actual(nxp::kTone);
    p.modulation      = actual(nxp::kModAmount);
    p.modRateHz       = actual(nxp::kModRate);
    p.earlyLevelDb    = actual(nxp::kEarlyLevel);
    p.earlySize       = actual(nxp::kEarlySize);
    p.earlyCharacter  = actual(nxp::kEarlyCharacter);
    p.lowControl      = actual(nxp::kLowControl);
    p.damping         = actual(nxp::kDamping);
    p.diffusion       = actual(nxp::kDiffusion);
    p.mix             = actual(nxp::kMix);
    p.outputDb        = actual(nxp::kOutput);
    return p;
}

void Processor::publishMeters(Steinberg::Vst::IParameterChanges* changes,
                              float inL, float inR, float outL, float outR) noexcept {
    if (!changes) return;
    const std::array<std::pair<nxp::ParamID, float>, 4> values {{
        {nxp::kInputPeakL, inL}, {nxp::kInputPeakR, inR},
        {nxp::kOutputPeakL, outL}, {nxp::kOutputPeakR, outR}
    }};
    for (const auto& item : values) {
        Steinberg::int32 index = 0;
        if (auto* q = changes->addParameterData(item.first, index)) {
            Steinberg::int32 pointIndex = 0;
            q->addPoint(0, nxp::clamp01(item.second), pointIndex);
        }
    }
}

Steinberg::tresult PLUGIN_API Processor::process(Steinberg::Vst::ProcessData& data) {
    ScopedDenormalGuard denormalGuard;
    readParameterChanges(data.inputParameterChanges);

    if (data.numSamples <= 0) return Steinberg::kResultOk;
    if (data.symbolicSampleSize != Steinberg::Vst::kSample32) return Steinberg::kResultFalse;
    if (data.numInputs < 1 || data.numOutputs < 1) return Steinberg::kResultOk;
    if (data.inputs[0].numChannels < 2 || data.outputs[0].numChannels < 2) return Steinberg::kResultFalse;

    auto* inL = data.inputs[0].channelBuffers32[0];
    auto* inR = data.inputs[0].channelBuffers32[1];
    auto* outL = data.outputs[0].channelBuffers32[0];
    auto* outR = data.outputs[0].channelBuffers32[1];
    if (!inL || !inR || !outL || !outR) return Steinberg::kResultFalse;

    if (outL != inL) std::memcpy(outL, inL, static_cast<std::size_t>(data.numSamples) * sizeof(float));
    if (outR != inR) std::memcpy(outR, inR, static_cast<std::size_t>(data.numSamples) * sizeof(float));

    const float inPeakL = peakOf(outL, data.numSamples);
    const float inPeakR = peakOf(outR, data.numSamples);

    engine_.setParameters(makeParameters());
    engine_.process(outL, outR, data.numSamples);

    const float outPeakL = peakOf(outL, data.numSamples);
    const float outPeakR = peakOf(outR, data.numSamples);
    publishMeters(data.outputParameterChanges, inPeakL, inPeakR, outPeakL, outPeakR);

    data.outputs[0].silenceFlags = 0;
    return Steinberg::kResultOk;
}

Steinberg::uint32 PLUGIN_API Processor::getTailSamples() {
    // Conservative maximum: 20 s user decay plus room for early/deferred energy.
    const double samples = std::max(1.0, sampleRate_) * 21.0;
    const double max32 = static_cast<double>(0xFFFFFFFEu);
    return static_cast<Steinberg::uint32>(std::min(samples, max32));
}

Steinberg::tresult PLUGIN_API Processor::getState(Steinberg::IBStream* state) {
    if (!state) return Steinberg::kResultFalse;
    Steinberg::IBStreamer stream(state, Steinberg::kLittleEndian);
    if (!stream.writeInt32(static_cast<Steinberg::int32>(kStateMagic))) return Steinberg::kResultFalse;
    if (!stream.writeInt32(kStateVersion)) return Steinberg::kResultFalse;
    if (!stream.writeInt32(static_cast<Steinberg::int32>(nxp::kParamCount))) return Steinberg::kResultFalse;
    for (auto value : normalized_)
        if (!stream.writeDouble(value)) return Steinberg::kResultFalse;
    return Steinberg::kResultOk;
}

Steinberg::tresult PLUGIN_API Processor::setState(Steinberg::IBStream* state) {
    if (!state) return Steinberg::kResultFalse;
    Steinberg::IBStreamer stream(state, Steinberg::kLittleEndian);
    Steinberg::int32 magic = 0, version = 0, count = 0;
    if (!stream.readInt32(magic) || !stream.readInt32(version) || !stream.readInt32(count))
        return Steinberg::kResultFalse;
    if (static_cast<Steinberg::uint32>(magic) != kStateMagic || version != kStateVersion || count != nxp::kParamCount)
        return Steinberg::kResultFalse;
    for (auto& value : normalized_) {
        if (!stream.readDouble(value)) return Steinberg::kResultFalse;
        value = nxp::clamp01(value);
    }
    engine_.setParameters(makeParameters());
    return Steinberg::kResultOk;
}

} // namespace nexuspace
