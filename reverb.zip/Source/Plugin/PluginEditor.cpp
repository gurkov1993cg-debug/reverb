#include "PluginEditor.hpp"
#include <cmath>

static juce::Colour bg(){return juce::Colour(0xff0d1318);}
static juce::Colour panel(){return juce::Colour(0xff151d23);}
static juce::Colour panel2(){return juce::Colour(0xff111920);}
static juce::Colour blue(){return juce::Colour(0xff63bfff);}
static juce::Colour text(){return juce::Colour(0xffd8e0e7);}

ParameterKnob::ParameterKnob(nxp::Parameter& p,juce::String label):p_(p),label_(std::move(label)){
    editor_.setVisible(false);
    editor_.setJustification(juce::Justification::centred);
    editor_.setSelectAllWhenFocused(true);
    editor_.setColour(juce::TextEditor::backgroundColourId,panel());
    editor_.setColour(juce::TextEditor::textColourId,text());
    editor_.setColour(juce::TextEditor::outlineColourId,blue());
    editor_.setColour(juce::TextEditor::focusedOutlineColourId,blue());
    editor_.onReturnKey=[this]{commitEdit();};
    editor_.onEscapeKey=[this]{editor_.setVisible(false);};
    editor_.onFocusLost=[this]{if(editor_.isVisible())commitEdit();};
    addAndMakeVisible(editor_);
    startTimerHz(15);
}

juce::Rectangle<float> ParameterKnob::knobArea() const {
    return getLocalBounds().toFloat().withTrimmedTop(18).withTrimmedBottom(24).reduced(7);
}
juce::Rectangle<float> ParameterKnob::valueArea() const {
    auto r=getLocalBounds().toFloat();
    return {r.getX()+3.0f,r.getBottom()-22.0f,r.getWidth()-6.0f,20.0f};
}
void ParameterKnob::paint(juce::Graphics& g){
    auto k=knobArea();
    auto c=k.getCentre();
    const float rad=std::min(k.getWidth(),k.getHeight())*0.45f;
    g.setColour(text().withAlpha(0.75f));
    g.setFont(12.0f);
    g.drawFittedText(label_,getLocalBounds().removeFromTop(16),juce::Justification::centred,1);

    g.setColour(juce::Colour(0xff222c34));
    g.fillEllipse(c.x-rad,c.y-rad,2.0f*rad,2.0f*rad);
    g.setColour(juce::Colour(0xff3b4852));
    g.drawEllipse(c.x-rad,c.y-rad,2.0f*rad,2.0f*rad,1.2f);

    const float a0=juce::MathConstants<float>::pi*1.25f;
    const float a1=juce::MathConstants<float>::pi*2.75f;
    const float a=a0+(a1-a0)*p_.getValue();
    juce::Path arc;
    arc.addCentredArc(c.x,c.y,rad+5.0f,rad+5.0f,0.0f,a0,a,true);
    g.setColour(blue());
    g.strokePath(arc,juce::PathStrokeType(3.0f));
    const juce::Point<float> q(c.x+std::cos(a)*rad*0.72f,c.y+std::sin(a)*rad*0.72f);
    g.drawLine(c.x,c.y,q.x,q.y,2.0f);

    if(!editor_.isVisible()){
        g.setColour(text());
        g.setFont(12.0f);
        g.drawFittedText(p_.getText(p_.getValue(),32),valueArea().toNearestInt(),juce::Justification::centred,1);
    }
}
void ParameterKnob::resized(){editor_.setBounds(valueArea().toNearestInt());}
void ParameterKnob::mouseDown(const juce::MouseEvent& e){
    if(valueArea().contains(e.position)){
        beginEdit();
        return;
    }
    startNorm_=p_.getValue();
    startY_=e.getScreenY();
    p_.beginChangeGesture();
    gestureActive_=true;
}
void ParameterKnob::mouseDrag(const juce::MouseEvent& e){
    if(editor_.isVisible() || !gestureActive_)return;
    const float fine=e.mods.isShiftDown()?520.0f:180.0f;
    const float n=juce::jlimit(0.0f,1.0f,startNorm_+(startY_-e.getScreenY())/fine);
    p_.setValueNotifyingHost(n);
}
void ParameterKnob::mouseUp(const juce::MouseEvent&){
    if(gestureActive_){p_.endChangeGesture();gestureActive_=false;}
}
void ParameterKnob::mouseDoubleClick(const juce::MouseEvent&){
    resetToDefault();
}
void ParameterKnob::beginEdit(){
    if(gestureActive_){p_.endChangeGesture();gestureActive_=false;}
    editor_.setText(p_.getText(p_.getValue(),32),false);
    editor_.setVisible(true);
    editor_.grabKeyboardFocus();
    editor_.selectAll();
}
void ParameterKnob::commitEdit(){
    if(!editor_.isVisible())return;
    const float normalized=p_.getValueForText(editor_.getText());
    p_.beginChangeGesture();
    p_.setValueNotifyingHost(normalized);
    p_.endChangeGesture();
    editor_.setVisible(false);
    repaint();
}
void ParameterKnob::resetToDefault(){
    if(gestureActive_){p_.endChangeGesture();gestureActive_=false;}
    editor_.setVisible(false);
    p_.beginChangeGesture();
    p_.setActualNotifyingHost(p_.defaultActual());
    p_.endChangeGesture();
    repaint();
}

void LevelMeter::paint(juce::Graphics& g){
    auto r=getLocalBounds().toFloat().reduced(4.0f);
    g.setColour(panel());
    g.fillRoundedRectangle(r,5.0f);
    auto title=r.removeFromTop(18.0f);
    g.setColour(text().withAlpha(0.68f));
    g.setFont(10.0f);
    g.drawText("IN      OUT",title.toNearestInt(),juce::Justification::centred);

    const float gap=4.0f;
    const float barW=(r.getWidth()-3.0f*gap)/4.0f;
    const float values[4]={inL_,inR_,outL_,outR_};
    for(int i=0;i<4;++i){
        const float x=r.getX()+static_cast<float>(i)*(barW+gap);
        g.setColour(juce::Colour(0xff26313a));
        g.fillRoundedRectangle(x,r.getY(),barW,r.getHeight(),2.0f);
        const float db=nx::gainToDb(values[i]);
        const float norm=juce::jlimit(0.0f,1.0f,(db+60.0f)/60.0f);
        const float h=r.getHeight()*norm;
        g.setColour(blue());
        g.fillRoundedRectangle(x,r.getBottom()-h,barW,h,2.0f);
    }
}

void ReverbView::paint(juce::Graphics& g){
    auto r=getLocalBounds().toFloat();
    g.setColour(panel());
    g.fillRoundedRectangle(r,6.0f);

    const int selected=juce::jlimit(0,3,static_cast<int>(std::round(p_.param(NexuspaceAudioProcessor::SpaceType).actual())));
    static const char* names[4]={"HALL","CHAMBER","ROOM","CLOUD"};

    g.setColour(juce::Colour(0xff29343c));
    for(int i=1;i<8;++i){
        const float x=r.getX()+r.getWidth()*static_cast<float>(i)/8.0f;
        g.drawVerticalLine(static_cast<int>(x),r.getY()+22.0f,r.getBottom()-18.0f);
    }

    const float decay=p_.param(NexuspaceAudioProcessor::Decay).actual();
    const float bloom=p_.param(NexuspaceAudioProcessor::Bloom).actual();
    const float focus=p_.param(NexuspaceAudioProcessor::Focus).actual();
    juce::Path path;
    constexpr int pts=84;
    for(int i=0;i<pts;++i){
        const float t=static_cast<float>(i)/(pts-1);
        const float modeShape[4]={1.0f,1.18f,1.45f,0.78f};
        const float env=std::exp(-t*(1.35f+7.0f/(decay*modeShape[selected])));
        const float rise=1.0f-std::exp(-t*(3.0f+14.0f*(1.0f-bloom)));
        const float front=0.72f+0.28f*(1.0f-focus);
        const float wave=std::sin(t*(50.0f+7.0f*selected))+0.34f*std::sin(t*(91.0f+3.0f*selected));
        const float y=r.getCentreY()-env*rise*front*(0.37f*r.getHeight())*wave;
        const float x=r.getX()+12.0f+t*(r.getWidth()-24.0f);
        if(i==0)path.startNewSubPath(x,y);else path.lineTo(x,y);
    }
    g.setColour(blue().withAlpha(0.86f));
    g.strokePath(path,juce::PathStrokeType(2.0f));

    g.setColour(text().withAlpha(0.70f));
    g.setFont(12.0f);
    auto top=r.toNearestInt().reduced(12).removeFromTop(18);
    g.drawText(juce::String(names[selected])+"  •  LIVING TAIL",top,juce::Justification::left);
}

NexuspaceAudioProcessorEditor::NexuspaceAudioProcessorEditor(NexuspaceAudioProcessor& p)
:juce::AudioProcessorEditor(&p),p_(p),view_(p){
    setSize(1120,700);
    setResizable(true,true);
    setResizeLimits(900,580,1500,950);
    addAndMakeVisible(view_);
    addAndMakeVisible(meter_);

    const int map[16]={
        NexuspaceAudioProcessor::Decay,NexuspaceAudioProcessor::Predelay,NexuspaceAudioProcessor::Bloom,NexuspaceAudioProcessor::Focus,
        NexuspaceAudioProcessor::Width,NexuspaceAudioProcessor::Tone,NexuspaceAudioProcessor::ModAmount,NexuspaceAudioProcessor::ModRate,
        NexuspaceAudioProcessor::EarlyLevel,NexuspaceAudioProcessor::EarlySize,NexuspaceAudioProcessor::EarlyCharacter,NexuspaceAudioProcessor::LowControl,
        NexuspaceAudioProcessor::Damping,NexuspaceAudioProcessor::Diffusion,NexuspaceAudioProcessor::Mix,NexuspaceAudioProcessor::Output
    };
    for(int i=0;i<16;++i){
        knobs_[i]=std::unique_ptr<ParameterKnob>(new ParameterKnob(p_.param(map[i]),p_.param(map[i]).getName(32)));
        addAndMakeVisible(*knobs_[i]);
    }
    static const char* typeLabels[4] = {"HALL", "CHAMBER", "ROOM", "CLOUD"};
    for(int i=0;i<4;++i){
        auto& b=typeButtons_[i];
        b.setButtonText(typeLabels[i]);
        addAndMakeVisible(b);
        b.setColour(juce::TextButton::buttonColourId,panel());
        b.setColour(juce::TextButton::textColourOffId,text());
        b.setColour(juce::TextButton::buttonOnColourId,blue().withAlpha(0.35f));
        b.setClickingTogglesState(false);
        b.onClick=[this,i]{
            auto& pp=p_.param(NexuspaceAudioProcessor::SpaceType);
            pp.beginChangeGesture();
            pp.setActualNotifyingHost(static_cast<float>(i));
            pp.endChangeGesture();
        };
    }
    startTimerHz(15);
}
void NexuspaceAudioProcessorEditor::paint(juce::Graphics& g){
    g.fillAll(bg());
    g.setColour(panel2());
    g.fillRect(getLocalBounds().removeFromTop(70));
    g.setColour(text());
    g.setFont(juce::Font(26.0f,juce::Font::plain));
    g.drawText("N E X U S P A C E",28,15,420,30,juce::Justification::left);
    g.setFont(11.0f);
    g.setColour(text().withAlpha(0.55f));
    g.drawText("PROFESSIONAL REVERB  •  CLEAR FRONT / LIVING TAIL",30,44,500,18,juce::Justification::left);
    g.drawText("v0.2.0",getWidth()-110,22,78,18,juce::Justification::right);
}
void NexuspaceAudioProcessorEditor::resized(){
    auto area=getLocalBounds().reduced(22);
    area.removeFromTop(68);
    auto top=area.removeFromTop(static_cast<int>(area.getHeight()*0.38f));
    auto left=top.removeFromLeft(150);
    for(int i=0;i<4;++i)typeButtons_[i].setBounds(left.removeFromTop(48).reduced(2));
    auto meterArea=top.removeFromRight(96);
    meter_.setBounds(meterArea.reduced(8));
    view_.setBounds(top.reduced(8));
    area.removeFromTop(8);
    constexpr int cols=8;
    const int cellW=area.getWidth()/cols;
    const int cellH=area.getHeight()/2;
    for(int i=0;i<16;++i){
        const int row=i/cols,col=i%cols;
        knobs_[i]->setBounds(area.getX()+col*cellW,area.getY()+row*cellH,cellW,cellH);
    }
}
void NexuspaceAudioProcessorEditor::timerCallback(){
    const float selected=p_.param(NexuspaceAudioProcessor::SpaceType).actual();
    for(int i=0;i<4;++i)typeButtons_[i].setToggleState(static_cast<int>(std::round(selected))==i,juce::dontSendNotification);
    meter_.set(p_.inputPeakL(),p_.inputPeakR(),p_.outputPeakL(),p_.outputPeakR());
    view_.repaint();
}
