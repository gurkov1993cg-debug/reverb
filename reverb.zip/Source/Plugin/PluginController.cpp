#include "PluginController.hpp"
#include "PluginIDs.hpp"
#include "NxParameter.hpp"

#include "base/source/fstreamer.h"
#include "base/source/fstring.h"
#include "pluginterfaces/base/fstrdefs.h"
#include "vstgui/lib/controls/ccontrol.h"

namespace nexuspace {

namespace {
constexpr Steinberg::uint32 kStateMagic = 0x5053584Eu;
constexpr Steinberg::int32 kStateVersion = 2;
}

Steinberg::tresult PLUGIN_API Controller::initialize(Steinberg::FUnknown* context) {
    // NEXUSPACE UI rule: double-click any continuous control to restore its declared default.
    VSTGUI::CControl::CheckDefaultValueEventFunc = [] (VSTGUI::CControl*, VSTGUI::MouseDownEvent& event) {
        return event.buttonState.isLeft() && event.clickCount == 2;
    };

    auto result = EditControllerEx1::initialize(context);
    if (result != Steinberg::kResultOk) return result;

    for (const auto& spec : nxp::kSpecs)
        parameters.addParameter(nxp::createParameter(spec));

    parameters.addParameter(STR16("Input L"),  nullptr, Steinberg::Vst::kStepCountContinuous, 0.0,
                            Steinberg::Vst::ParameterInfo::kIsReadOnly, nxp::kInputPeakL);
    parameters.addParameter(STR16("Input R"),  nullptr, Steinberg::Vst::kStepCountContinuous, 0.0,
                            Steinberg::Vst::ParameterInfo::kIsReadOnly, nxp::kInputPeakR);
    parameters.addParameter(STR16("Output L"), nullptr, Steinberg::Vst::kStepCountContinuous, 0.0,
                            Steinberg::Vst::ParameterInfo::kIsReadOnly, nxp::kOutputPeakL);
    parameters.addParameter(STR16("Output R"), nullptr, Steinberg::Vst::kStepCountContinuous, 0.0,
                            Steinberg::Vst::ParameterInfo::kIsReadOnly, nxp::kOutputPeakR);

    return Steinberg::kResultOk;
}

Steinberg::tresult PLUGIN_API Controller::setComponentState(Steinberg::IBStream* state) {
    if (!state) return Steinberg::kResultFalse;
    Steinberg::IBStreamer stream(state, kLittleEndian);
    Steinberg::int32 magic = 0, version = 0, count = 0;
    if (!stream.readInt32(magic) || !stream.readInt32(version) || !stream.readInt32(count))
        return Steinberg::kResultFalse;
    if (static_cast<Steinberg::uint32>(magic) != kStateMagic || version != kStateVersion || count != nxp::kParamCount)
        return Steinberg::kResultFalse;

    for (Steinberg::int32 i = 0; i < count; ++i) {
        double value = 0.0;
        if (!stream.readDouble(value)) return Steinberg::kResultFalse;
        setParamNormalized(static_cast<Steinberg::Vst::ParamID>(i), nxp::clamp01(value));
    }
    return Steinberg::kResultOk;
}

Steinberg::IPlugView* PLUGIN_API Controller::createView(const char* name) {
    Steinberg::ConstString viewName(name);
    if (viewName == Steinberg::Vst::ViewType::kEditor)
        return new VSTGUI::VST3Editor(this, "view", "NEXUSPACE.uidesc");
    return nullptr;
}

} // namespace nexuspace
