#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.hpp"
#include <array>
#include <memory>

class ParameterKnob final : public juce::Component, private juce::Timer {
public:
    ParameterKnob(nxp::Parameter&, juce::String label);
    void paint(juce::Graphics&) override;
    void resized() override;
    void mouseDown(const juce::MouseEvent&) override;
    void mouseDrag(const juce::MouseEvent&) override;
    void mouseUp(const juce::MouseEvent&) override;
    void mouseDoubleClick(const juce::MouseEvent&) override;
private:
    nxp::Parameter& p_;
    juce::String label_;
    float startNorm_=0.0f;
    int startY_=0;
    bool gestureActive_=false;
    juce::TextEditor editor_;
    juce::Rectangle<float> knobArea() const;
    juce::Rectangle<float> valueArea() const;
    void beginEdit();
    void commitEdit();
    void resetToDefault();
    void timerCallback() override { repaint(); }
};

class LevelMeter final : public juce::Component {
public:
    void set(float inL,float inR,float outL,float outR){inL_=inL;inR_=inR;outL_=outL;outR_=outR;repaint();}
    void paint(juce::Graphics&) override;
private:
    float inL_=0.0f,inR_=0.0f,outL_=0.0f,outR_=0.0f;
};

class ReverbView final : public juce::Component {
public:
    explicit ReverbView(NexuspaceAudioProcessor& p):p_(p){}
    void paint(juce::Graphics&) override;
private:
    NexuspaceAudioProcessor& p_;
};

class NexuspaceAudioProcessorEditor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit NexuspaceAudioProcessorEditor(NexuspaceAudioProcessor&);
    ~NexuspaceAudioProcessorEditor() override = default;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    NexuspaceAudioProcessor& p_;
    std::array<std::unique_ptr<ParameterKnob>,16> knobs_;
    std::array<juce::TextButton,4> typeButtons_{};
    ReverbView view_;
    LevelMeter meter_;
    void timerCallback() override;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(NexuspaceAudioProcessorEditor)
};
