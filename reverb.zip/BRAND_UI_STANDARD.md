# VETRA AUDIO — Plugin Brand UI Standard

## Reference intent
The approved Console Channel Strip X image is a reference for visual language and brand identity only. It is NOT a template for layout, sections, functions, number of controls or control positions.

## Shared visual DNA
- dark graphite / professional studio-panel appearance
- restrained cold-blue active states
- functional color coding where useful
- consistent panel framing, typography, numeric fields and buttons
- compact, premium, hardware-inspired controls

## Rotary knob family
- compact dark round body
- shallow machined/hardware appearance
- fine outer bezel
- subtle segmented tick ring
- thin light/white position indicator
- functional color appears mainly in the outer ring/ticks/marker
- no oversized glossy 3D knobs
- no thick neon halo rings
- same core knob shape across the product family; larger variants only for genuinely primary parameters

## Meter family
- smooth continuous level bars, not square/block LED meters
- fine dB scale
- clear peak-hold marker
- restrained continuous level color progression from green through yellow/orange toward red
- compact and premium appearance consistent across plugins

## Footer / brand area
- retain enough breathing room for a premium appearance
- do not crush the footer into a thin clipped strip
- brand mark/name sits discreetly at lower right unless the product layout calls for another intentional placement
- avoid redundant slogans and decorative copy
- never rearrange functional sections merely to make room for branding

## Functional GUI rules
- every visible control must be real and connected to a real parameter
- no static PNG facade with invisible hit zones
- all numeric parameters support precise manual entry
- double-click on a control resets it to its defined default value
- layouts are designed per plugin function and signal flow, not copied from the visual reference
- do not generate new visual mockups unless explicitly requested
