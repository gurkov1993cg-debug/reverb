# NEXUSPACE v0.4.1 status

## Current milestone: Steinberg-native VST3 migration

The custom C++ reverb DSP remains intact. The plug-in wrapper has been migrated away from JUCE to the official Steinberg VST3 SDK.

Current architecture:
- `Processor` derives directly from Steinberg `AudioEffect`
- `Controller` derives directly from Steinberg `EditControllerEx1`
- VST3 parameters/state are implemented through Steinberg SDK classes
- editor is created through Steinberg VSTGUI `VST3Editor`
- `Resources/NEXUSPACE.uidesc` contains real parameter controls
- four read-only peak parameters are published by the audio processor for smooth meter controls
- no JUCE dependency in active source or CMake

DSP milestone remains unchanged:
- custom Early Reflections
- 4-stage custom diffusion
- 8-line custom FDN
- stable frequency-dependent RT60 feedback shaping
- Low Control and Damping inside the feedback network
- modulated feedback delays with stability-safe interpolation
- Bloom
- predelay-aligned Focus with deferred transient injection
- stereo decorrelation / width
- tone shaping
- parameter smoothing in critical feedback/diffusion paths
- zero-allocation realtime processing test
- 44.1 / 48 / 96 kHz validation
- long-decay stress validation
- dedicated DSP sound audit

Next build validation is performed by the canonical GitHub macOS workflow against Steinberg VST3 SDK 3.8.1.

## macOS CI fix

Top-level CMake explicitly enables `OBJCXX` on Apple platforms. This fixes the Steinberg VST3 SDK 3.8.x Unix Makefiles generation failure where `CMAKE_OBJCXX_COMPILE_OBJECT` was missing.
