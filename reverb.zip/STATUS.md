# NEXUSPACE status

Current source package: 0.5.0 GUI lock pass.

- Direct Steinberg VST3 SDK plug-in wrapper.
- No JUCE in active source/build files.
- Existing custom NEXUSPACE DSP retained unchanged.
- Approved section layout restored in `Resources/NEXUSPACE.uidesc`.
- Numeric text entry retained for all numeric controls.
- Double-click reset-to-default configured for VSTGUI controls.
- macOS Intel x86-64 / deployment target 10.13 remains the build target.
- The 0.5.0 GUI source package still requires GitHub Actions/macOS build verification before it is called a finished binary.
