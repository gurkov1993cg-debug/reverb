# NEXUSPACE changelog

## 0.4.0 — Steinberg VST3 SDK migration

- Fixed macOS Unix Makefiles configuration for Steinberg VST3 SDK 3.8.x by enabling Objective-C++ (`OBJCXX`) at the top project level.

- Removed JUCE from the active project architecture and build.
- Replaced the plug-in wrapper with direct Steinberg VST3 SDK `AudioEffect` + `EditControllerEx1` classes.
- Added native VST3 parameter queues, controller parameter objects, component state restore/save and processor/controller FUIDs.
- Added Steinberg VSTGUI editor resource with real controls and direct numeric edit fields.
- Added read-only input/output peak parameters for smooth meter bindings.
- Reworked CMake around `smtg_add_vst3plugin`, `sdk` and `vstgui_support`.
- GitHub Actions now fetches a pinned Steinberg VST3 SDK 3.8.1 commit and refuses active source/build files that contain a JUCE dependency.
- Existing custom DSP core and tests remain unchanged.

## 0.3.0 — Sound Audit / Commercial Tail

DSP changes:
- Rebuilt the FDN damping path as a stable, attenuation-only, frequency-dependent feedback network.
- `Decay` now tracks the mid-band RT60 much more consistently from short to very long settings.
- Low-end decay and high-frequency damping are controlled independently inside the feedback loop instead of repeatedly filtering the whole wet signal.
- Replaced cubic interpolation inside the FDN feedback delays with bounded linear interpolation for long-decay stability; cubic interpolation remains where it is outside the critical feedback loop.
- Reworked `Focus` so it is time-aligned after predelay.
- Added deferred transient injection: Focus moves part of sharp transient energy later into the dense field rather than simply deleting it.
- Orthogonalized the stereo output projection to reduce excessive anti-correlation and improve mono compatibility.
- Smoothed feedback gains, damping filter coefficients, and all-pass diffusion gains to reduce zipper/pitch artifacts during automation.
- Fixed all-pass diffusion timing so changing Diffusion no longer moves delay taps block-by-block.
- Rebalanced Hall / Chamber / Room / Cloud late-tail output levels; isolated tail energy spread is now about 0.33 dB in the audit.
- Added long-decay stress checking and a dedicated sound-audit executable.

Performance:
- No audio-thread allocations in the realtime test.
- Current local benchmark: about 48x realtime for the DSP core at 48 kHz stereo under the benchmark conditions. This is not an iMac 2011 measurement.
