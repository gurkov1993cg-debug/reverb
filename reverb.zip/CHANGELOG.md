# NEXUSPACE changelog

## 0.3.0 — Sound Audit / Commercial Tail

DSP changes:
- Rebuilt the FDN damping path as a stable, attenuation-only, frequency-dependent feedback network.
- `Decay` now tracks the mid-band RT60 much more consistently from short to very long settings.
- Low-end decay and high-frequency damping are controlled independently inside the feedback loop instead of repeatedly filtering the whole wet signal.
- Replaced cubic interpolation inside the FDN feedback delays with bounded linear interpolation for long-decay stability; cubic interpolation remains where it is outside the critical feedback loop.
- Reworked `Focus` so it is time-aligned after predelay.
- Added deferred transient injection: Focus moves part of sharp transient energy later into the dense field rather than simply deleting it.
- Orthogonalized the stereo output projection to reduce excessive anti-correlation and improve mono compatibility.
- Smoothed feedback gains, damping filter coefficients, and all-pass diffusion gains to reduce zipper/pitch artifacts during automation.
- Fixed all-pass diffusion timing so changing Diffusion no longer moves delay taps block-by-block.
- Rebalanced Hall / Chamber / Room / Cloud late-tail output levels; isolated tail energy spread is now about 0.33 dB in the audit.
- Added long-decay stress checking and a dedicated sound-audit executable.

Performance:
- No audio-thread allocations in the realtime test.
- Current local benchmark: about 48x realtime for the DSP core at 48 kHz stereo under the benchmark conditions. This is not an iMac 2011 measurement.
